# 🚀 Getting Started - Gamification System

## ✨ What You Have

A complete, production-ready gamification system with:
- ✅ Plugin-based architecture (add new reward types easily)
- ✅ Event-driven integration (no tight coupling)
- ✅ Beautiful web dashboard
- ✅ Complete documentation
- ✅ Ready to deploy

---

## 📖 Reading Order (Start Here!)

### 1. **This File** (You are here!)
   → Overview and how to start

### 2. **QUICK_REFERENCE.md** (5 minutes)
   → Fast start guide with basic commands

### 3. **IMPLEMENTATION_SUMMARY.md** (10 minutes)
   → What was built and why

### 4. **README.md** (20 minutes)
   → Complete technical documentation

### 5. **GAMIFICATION_SETUP_GUIDE.md** (30+ minutes)
   → Detailed setup, testing, and troubleshooting

### 6. **FILE_INVENTORY.md** (Reference)
   → Complete list of all files created/modified

---

## 🚀 Quick Start (3 Commands)

### Terminal 1: Start MySQL
```bash
mysql -u root -p
# Just start MySQL, no commands needed
# Database will auto-create via Hibernate
```

### Terminal 2: Start Banking App
```bash
cd cib-fund-transfer
mvn spring-boot:run

# Wait for: "Started FundTransferApplication in X seconds"
# Server: http://localhost:8080
```

### Terminal 3: Start Gamification Service
```bash
cd gamification-service
mvn spring-boot:run

# Wait for: "Started GamificationApplication in X seconds"
# Server: http://localhost:8081
# Dashboard: http://localhost:8081/dashboard.html
```

---

## 🎮 2-Minute Demo

### Step 1: Create Referrer (Alice)
```bash
curl -X POST http://localhost:8080/api/makers \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice"}'

# Note the userId: 1
```

### Step 2: Create Referred User (Bob)
```bash
curl -X POST http://localhost:8080/api/makers \
  -H "Content-Type: application/json" \
  -d '{"name": "Bob", "referralId": "1"}'

# Note the userId: 2
# 🎯 Bob automatically gets 100 points!
```

### Step 3: Verify Rewards
```bash
curl http://localhost:8081/api/gamification/profile/2

# Result:
# {
#   "userId": 2,
#   "totalPoints": 100,
#   "currentLevel": 1,
#   "totalBadges": 0
# }
# 
# ✨ Success! Bob earned 100 points!
```

### Step 4: View in Dashboard
1. Open browser: **http://localhost:8081/dashboard.html**
2. Go to **"👤 Profile"** tab
3. Enter User ID: **2**
4. See: **100 Total Points** ✨

---

## 🎯 What Happens Automatically

When you create a maker with a referral ID:

```
Step 1: MakerService.createMaker()
        ↓ (detects referralId is provided)
Step 2: Calls GamificationEventPublisher.publishUserReferred()
        ↓ (sends HTTP POST to gamification service)
Step 3: GamificationService.processEvent()
        ↓ (evaluates USER_REFERRED rule)
Step 4: Finds rule: USER_REFERRED → POINTS (100)
        ↓
Step 5: Executes PointsRewardPlugin
        ↓ (adds 100 points to user's profile)
Step 6: Updates database tables:
        - user_gamification_profile (totalPoints = 100)
        - user_reward_ledger (records the reward)
Step 7: Dashboard shows update in real-time
        ✨ User profile displays 100 points!
```

**All happens automatically - no manual intervention needed!**

---

## 📊 Database Tables

These tables are **auto-created** when you start the gamification service:

### 1. gamification_rules
Contains all reward rules:
- Referral: USER_REFERRED → 100 POINTS
- Transaction: TRANSACTION_COMPLETED → 25 POINTS
- Milestone: MILESTONE_3_TXNS_7_DAYS → 1 BADGE

### 2. user_gamification_profile
Tracks each user's progress:
- totalPoints
- currentLevel
- totalBadges

### 3. user_reward_ledger
Complete audit trail of every reward

### 4. user_badges
Tracks earned badges

---

## 🌐 Key APIs

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/gamification/profile/{userId}` | GET | Get user's points, level, badges |
| `/api/gamification/history/{userId}` | GET | Get all rewards earned |
| `/api/gamification/badges/{userId}` | GET | Get earned badges |
| `/api/gamification/rules` | GET | View active reward rules |
| `/api/gamification/event` | POST | Trigger a gamification event |

---

## 🧪 Test Events via Dashboard

After starting both services, go to:
**http://localhost:8081/dashboard.html**

Navigate to **"🧪 Test Events"** tab and try:

### Test 1: Transaction Reward
- Click "Test Transaction Completed"
- Enter User ID: 1
- Enter Amount: 5000
- Click "Test"
- Check Profile tab → User 1's points increased by 25!

### Test 2: Referral Reward
- Click "Test User Referred"
- Enter New User ID: 10
- Enter Referrer ID: 1
- Click "Test"
- Check Profile tab → User 10's points = 100!

### Test 3: Custom Event
- Click "Test Custom Event"
- Enter Event Name: TRANSACTION_COMPLETED
- Enter User ID: 1
- Click "Test"
- Event triggers immediately!

---

## 🔧 Common Tasks

### Check if Services are Running
```bash
# Banking app running?
curl http://localhost:8080/api/makers

# Gamification running?
curl http://localhost:8081/api/gamification/rules
```

### View User's Profile
```bash
curl http://localhost:8081/api/gamification/profile/2
```

### View User's Reward History
```bash
curl http://localhost:8081/api/gamification/history/2
```

### Add a New Reward Rule
```sql
INSERT INTO gamification_rules 
(event_name, reward_type, reward_value, status, description, valid_from, valid_to)
VALUES
('MY_EVENT', 'POINTS', 50, 'ACTIVE', 'My custom rule', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));
```

### Check What Rules Exist
```bash
curl http://localhost:8081/api/gamification/rules
```

---

## 📱 Dashboard Features

### Profile Tab
```
User ID: 2
├── Total Points: 100
├── Current Level: 1
├── Total Badges: 0
└── Progress to Next Level: [████░░░░░░] 20%
```

### Rewards & History Tab
```
Shows all rewards earned:
Event         Type    Value  Date
USER_REFERRED POINTS  100    2024-01-15 10:30
```

### Badges Tab
```
Badge Name     Date Earned
Power User     2024-01-15 10:30
```

### Rules Tab
```
Shows all active rules:
Event                    Type    Value  Valid From    Valid To
USER_REFERRED            POINTS  100    2024-01-01    2025-12-31
TRANSACTION_COMPLETED    POINTS  25     2024-01-01    2025-12-31
MILESTONE_3_TXNS_7_DAYS  BADGE   1      2024-01-01    2025-12-31
```

### Test Events Tab
```
🧪 Manual Testing

[Test Transaction Completed]
User ID: [input]
Amount: [input]

[Test User Referred]
New User ID: [input]
Referrer ID: [input]

[Test Custom Event]
Event Name: [input]
User ID: [input]
```

---

## ❓ Frequently Asked Questions

### Q: Do I need to do anything special to integrate gamification?
**A:** No! The integration is automatic:
- Banking app publishes events when activities occur
- Gamification service receives and processes them
- Just start both services

### Q: What if the gamification service is down?
**A:** Banking operations continue normally. The event publisher has error handling that prevents failures in the gamification service from affecting banking operations.

### Q: How do I add new reward types?
**A:** Create a new plugin class implementing `RewardPlugin`:
1. Create class extending RewardPlugin
2. Add @Component annotation
3. Implement getRewardType() and apply() methods
4. Spring auto-discovers it - done!

### Q: How do I add new rules?
**A:** Just insert into the database:
```sql
INSERT INTO gamification_rules 
(event_name, reward_type, reward_value, status)
VALUES 
('NEW_EVENT', 'POINTS', 100, 'ACTIVE');
```
No code changes needed!

### Q: Can I change the reward values?
**A:** Yes! Update the database:
```sql
UPDATE gamification_rules 
SET reward_value = 200 
WHERE event_name = 'USER_REFERRED';
```
Changes take effect immediately.

### Q: Where is my data stored?
**A:** All in the same `cib_fund_transfer` MySQL database:
- gamification_rules
- user_gamification_profile
- user_reward_ledger
- user_badges

### Q: Can I export user rewards?
**A:** Yes, query the user_reward_ledger table:
```sql
SELECT * FROM user_reward_ledger WHERE user_id = 2;
```

---

## 🎯 Next Steps

### Immediate (Do Now)
1. ✅ Read QUICK_REFERENCE.md (5 min)
2. ✅ Start MySQL
3. ✅ Start both services (3 terminals)
4. ✅ Run the 2-minute demo above
5. ✅ Open dashboard in browser

### Short Term (This Week)
1. ✅ Review README.md for complete documentation
2. ✅ Explore GAMIFICATION_SETUP_GUIDE.md
3. ✅ Test various scenarios via dashboard
4. ✅ Add new reward rules to database
5. ✅ Test creating new plugins

### Medium Term (Next Sprint)
1. Add admin UI for rule management
2. Implement coupon/voucher plugin
3. Add leaderboards
4. Send email notifications
5. Add user level tiers

---

## 📞 Troubleshooting

### "Connection refused" when accessing dashboard?
```
✓ Ensure gamification service is running on port 8081
✓ Check console logs for startup errors
```

### "Service not found" in curl commands?
```
✓ Both services must be running
✓ Banking app: port 8080
✓ Gamification: port 8081
✓ Check console logs
```

### "No rewards appear" after testing?
```
✓ Check that rules are ACTIVE in database
✓ Check rule's validFrom and validTo dates
✓ Check gamification service logs
✓ Try via dashboard Test Events tab
```

### "CORS error" in browser console?
```
✓ Verify CorsConfig.java exists in gamification-service
✓ Check that allowed origins include your frontend URL
✓ Restart gamification service
```

---

## 🎉 You're Ready!

Everything is set up and ready to go:

✅ Code compiled  
✅ Database schema ready  
✅ APIs functional  
✅ Dashboard deployed  
✅ Documentation complete  
✅ All services configured  

**Start the services and enjoy your gamified banking app!**

---

## 📚 Documentation Files

| File | Time | Purpose |
|------|------|---------|
| QUICK_REFERENCE.md | 5 min | Quick start commands |
| IMPLEMENTATION_SUMMARY.md | 10 min | What was built |
| README.md | 20 min | Complete overview |
| GAMIFICATION_SETUP_GUIDE.md | 30 min | Detailed setup & testing |
| FILE_INVENTORY.md | Reference | All files created/modified |

---

## 🌟 What Makes This Special

✨ **Plugin-Based** - Add new reward types without modifying core code  
✨ **Event-Driven** - Loose coupling between banking and gamification  
✨ **Data-Driven** - Rules in database, not hardcoded  
✨ **Observable** - Complete audit trail of all rewards  
✨ **Scalable** - Can handle high volume of events  
✨ **Extensible** - Easy to add new features  
✨ **Production-Ready** - Properly tested and documented  

---

## 🚀 Launch Commands (Copy-Paste)

```bash
# Terminal 1
mysql -u root -p

# Terminal 2
cd cib-fund-transfer && mvn spring-boot:run

# Terminal 3
cd gamification-service && mvn spring-boot:run

# Browser
# Open: http://localhost:8081/dashboard.html
```

---

**Enjoy building with your new gamification system! 🎮✨**
