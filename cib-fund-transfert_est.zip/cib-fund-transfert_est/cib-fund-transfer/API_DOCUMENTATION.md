# CIB Fund Transfer System — API Documentation

Base URL: `http://localhost:8080`

No authentication/login — every request identifies the acting user by passing their `userId` (`makerId` / `checkerId`) in the request body or path.

All error responses follow this shape:
```json
{
  "timestamp": "2026-08-10T10:15:30",
  "status": 400,
  "error": "Bad Request",
  "message": "Amount must be greater than zero"
}
```

---

## 1. Maker APIs

### 1.1 Create Maker
Creates a maker and automatically creates their account with a default balance of ₹1,00,000.

**Request**
```
POST /api/makers
Content-Type: application/json
```
```json
{
  "name": "Alice",
  "referralId": "1"
}
```

**Response `201 Created`**
```json
{
  "userId": 1,
  "name": "Alice",
  "accountId": 1,
  "accountNumber": "AC0000000001",
  "balance": 100000.00
}
```

**Errors**
| Status | Cause |
|---|---|
| 400 | `name` missing/blank |

---

### 1.2 Get Maker
Fetches a maker's profile and current account balance.

**Request**
```
GET /api/makers/{id}
```

**Response `200 OK`**
```json
{
  "userId": 1,
  "name": "Alice",
  "accountId": 1,
  "accountNumber": "AC0000000001",
  "balance": 95000.00
}
```

**Errors**
| Status | Cause |
|---|---|
| 404 | Maker not found / id belongs to a checker |

---

### 1.3 Get Beneficiaries
Returns all other makers (excludes self and checkers) that this maker can transfer funds to.

**Request**
```
GET /api/makers/{id}/beneficiaries
```

**Response `200 OK`**
```json
[
  {
    "userId": 2,
    "name": "Bob",
    "accountId": 2,
    "accountNumber": "AC0000000002",
    "balance": 100000.00
  },
  {
    "userId": 4,
    "name": "Dave",
    "accountId": 4,
    "accountNumber": "AC0000000004",
    "balance": 100000.00
  }
]
```

**Errors**
| Status | Cause |
|---|---|
| 404 | Maker `id` not found |

---

## 2. Checker APIs

### 2.1 Create Checker
Creates a checker. Checkers have **no account** and cannot initiate transfers.

**Request**
```
POST /api/checkers
Content-Type: application/json
```
```json
{
  "name": "Carol"
}
```

**Response `201 Created`**
```json
{
  "userId": 3,
  "name": "Carol"
}
```

**Errors**
| Status | Cause |
|---|---|
| 400 | `name` missing/blank |

---

### 2.2 Get Pending Transactions for Checker
Returns the combined inbox (level-1 and level-2 pending items) for a checker, excluding any transaction they themselves created (defensive check — cannot normally happen since checkers can't create transactions).

**Request**
```
GET /api/checkers/{id}/pending-transactions
```

**Response `200 OK`**
```json
[
  {
    "transactionId": 10,
    "createdAt": "2026-08-10T09:00:00",
    "updatedAt": "2026-08-10T09:00:00",
    "debitAccountId": 1,
    "beneficiaryAccountId": 2,
    "amount": 5000.00,
    "type": "DEBIT",
    "status": "PENDING_APPROVAL_L1",
    "twoLevelApprovalRequired": false,
    "createdBy": 1,
    "approvedByLevel1": null,
    "approvedByLevel2": null,
    "lastRejectionReason": null
  }
]
```

**Errors**
| Status | Cause |
|---|---|
| 404 | id not found / id belongs to a maker |

---

## 3. Transaction APIs

### 3.1 Create Fund Transfer
Creates a new fund transfer request. Only a valid Maker id can call this — passing a checker's id fails validation.

**Request**
```
POST /api/transactions
Content-Type: application/json
```
```json
{
  "makerId": 1,
  "beneficiaryUserId": 2,
  "amount": 5000
}
```

**Response `201 Created`**
```json
{
  "transactionId": 10,
  "createdAt": "2026-08-10T09:00:00",
  "updatedAt": "2026-08-10T09:00:00",
  "debitAccountId": 1,
  "beneficiaryAccountId": 2,
  "amount": 5000.00,
  "type": "DEBIT",
  "status": "PENDING_APPROVAL_L1",
  "twoLevelApprovalRequired": false,
  "createdBy": 1,
  "approvedByLevel1": null,
  "approvedByLevel2": null,
  "lastRejectionReason": null
}
```

**Validation Errors — `400 Bad Request`**
| Message | Cause |
|---|---|
| `amount must be greater than zero` | amount ≤ 0 |
| `Maker cannot select their own account as beneficiary` | `makerId == beneficiaryUserId` |
| `Insufficient balance in debit account` | balance < amount |
| `A similar transaction is already pending approval. Duplicate request rejected.` | identical pending debit+beneficiary+amount within last 5 minutes |

**Not Found Errors — `404 Not Found`**
| Message | Cause |
|---|---|
| `User not found with id: {id}` | `makerId` doesn't exist |
| `User id {id} is not a maker` | `makerId` belongs to a checker |
| `User id {id} is not a maker` | `beneficiaryUserId` belongs to a checker |
| `Debit account not found for maker id: {id}` | account missing (shouldn't happen normally) |
| `Beneficiary account not found for user id: {id}` | account missing (shouldn't happen normally) |

---

### 3.2 Get Transaction by ID

**Request**
```
GET /api/transactions/{id}
```

**Response `200 OK`** — same shape as 3.1 response.

**Errors**
| Status | Cause |
|---|---|
| 404 | Transaction not found |

---

### 3.3 Transaction History (by Maker)
Returns all transactions created by a maker, most recent first. Optional status filter.

**Request**
```
GET /api/transactions/maker/{makerId}
GET /api/transactions/maker/1
GET /api/transactions/maker/1?status=SUCCESS
```

Valid `status` values: `PENDING_APPROVAL_L1`, `PENDING_APPROVAL_L2`, `APPROVED`, `PROCESSING`, `SUCCESS`, `FAILED`, `REJECTED`

**Response `200 OK`**
```json
[
  {
    "transactionId": 10,
    "createdAt": "2026-08-10T09:00:00",
    "updatedAt": "2026-08-10T09:05:00",
    "debitAccountNumber": "AC0000000001",
    "beneficiaryAccountNumber": "AC0000000002",
    "amount": 5000.00,
    "type": "DEBIT",
    "status": "SUCCESS",
    "twoLevelApprovalRequired": false,
    "createdBy": 1,
    "approvedByLevel1Name": "Alice",
    "approvedByLevel2Name": null,
    "lastRejectionReason": null
  }
]
```

**Errors**
| Status | Cause |
|---|---|
| 404 | `makerId` not found |

---

### 3.4 Get Transaction Approval Flow (Timeline)
Returns the full detailed history of every approval action taken on a transaction, in order.

**Request**
```
GET /api/transactions/{id}/flow
```

**Response `200 OK`**
```json
[
  {
    "action": "CREATED",
    "actionBy": 1,
    "reason": null,
    "actedAt": "2026-08-10T09:00:00"
  },
  {
    "action": "APPROVED_L1",
    "actionBy": 3,
    "reason": null,
    "actedAt": "2026-08-10T09:02:00"
  },
  {
    "action": "REJECTED_L2",
    "actionBy": 5,
    "reason": "Amount looks unusual for this vendor",
    "actedAt": "2026-08-10T09:04:00"
  },
  {
    "action": "SENT_BACK_L1",
    "actionBy": 5,
    "reason": "Amount looks unusual for this vendor",
    "actedAt": "2026-08-10T09:04:00"
  },
  {
    "action": "APPROVED_L1",
    "actionBy": 3,
    "reason": null,
    "actedAt": "2026-08-10T09:06:00"
  },
  {
    "action": "APPROVED_L2",
    "actionBy": 5,
    "reason": null,
    "actedAt": "2026-08-10T09:08:00"
  }
]
```

Possible `action` values: `CREATED`, `APPROVED_L1`, `APPROVED_L2`, `REJECTED_L1`, `REJECTED_L2`, `SENT_BACK_L1`, `APPROVED_SINGLE`, `REJECTED_SINGLE`, `EXECUTION_FAILED`

**Errors**
| Status | Cause |
|---|---|
| 404 | Transaction not found |

---

### 3.5 Approve Transaction
Approves a transaction at whatever stage it's currently pending (level-1, level-2, or single-level). Automatically triggers execution (debit/credit) once fully approved.

**Request**
```
POST /api/transactions/{id}/approve
Content-Type: application/json
```
```json
{
  "checkerId": 3
}
```

**Response `200 OK`**

If more approval stages remain (e.g. two-level, currently at level 1):
```json
{
  "transactionId": 10,
  "createdAt": "2026-08-10T09:00:00",
  "updatedAt": "2026-08-10T09:02:00",
  "debitAccountId": 1,
  "beneficiaryAccountId": 2,
  "amount": 15000.00,
  "type": "DEBIT",
  "status": "PENDING_APPROVAL_L2",
  "twoLevelApprovalRequired": true,
  "createdBy": 1,
  "approvedByLevel1": 3,
  "approvedByLevel2": null,
  "lastRejectionReason": null
}
```

If this was the final approval (single-level, or level-2 of a two-level transfer):
```json
{
  "transactionId": 10,
  "createdAt": "2026-08-10T09:00:00",
  "updatedAt": "2026-08-10T09:08:00",
  "debitAccountId": 1,
  "beneficiaryAccountId": 2,
  "amount": 15000.00,
  "type": "DEBIT",
  "status": "SUCCESS",
  "twoLevelApprovalRequired": true,
  "createdBy": 1,
  "approvedByLevel1": 3,
  "approvedByLevel2": 5,
  "lastRejectionReason": null
}
```
`status` will be `FAILED` instead of `SUCCESS` if the debit account no longer had sufficient balance at execution time.

**Errors — `400 Bad Request`**
| Message | Cause |
|---|---|
| `You cannot approve your own transaction` | checker id == transaction creator id |
| `Transaction is not pending single-level approval` | wrong status for a single-level transaction |
| `Transaction is not pending approval` | wrong status for a two-level transaction |
| `Transaction has already been processed and is in status: {status}` | transaction already in a terminal state (SUCCESS/FAILED/REJECTED) |

**Errors — `404 Not Found`**
| Message | Cause |
|---|---|
| `Transaction not found with id: {id}` | invalid transaction id |
| `User not found with id: {id}` | invalid `checkerId` |
| `User id {id} is not a checker` | `checkerId` belongs to a maker |

---

### 3.6 Reject Transaction
Rejects a transaction. At level-1 (or single-level), this is terminal. At level-2, this sends the transaction back to level-1 for re-decision.

**Request**
```
POST /api/transactions/{id}/reject
Content-Type: application/json
```
```json
{
  "checkerId": 5,
  "reason": "Amount looks unusual for this vendor"
}
```

**Response `200 OK`**

Terminal rejection (level-1 or single-level):
```json
{
  "transactionId": 10,
  "createdAt": "2026-08-10T09:00:00",
  "updatedAt": "2026-08-10T09:03:00",
  "debitAccountId": 1,
  "beneficiaryAccountId": 2,
  "amount": 5000.00,
  "type": "DEBIT",
  "status": "REJECTED",
  "twoLevelApprovalRequired": false,
  "createdBy": 1,
  "approvedByLevel1": null,
  "approvedByLevel2": null,
  "lastRejectionReason": "Amount looks unusual for this vendor"
}
```

Sent back (level-2 rejection on a two-level transaction):
```json
{
  "transactionId": 11,
  "createdAt": "2026-08-10T09:00:00",
  "updatedAt": "2026-08-10T09:04:00",
  "debitAccountId": 1,
  "beneficiaryAccountId": 2,
  "amount": 15000.00,
  "type": "DEBIT",
  "status": "PENDING_APPROVAL_L1",
  "twoLevelApprovalRequired": true,
  "createdBy": 1,
  "approvedByLevel1": 3,
  "approvedByLevel2": null,
  "lastRejectionReason": "Amount looks unusual for this vendor"
}
```

**Errors — `400 Bad Request`**
| Message | Cause |
|---|---|
| `Rejection reason is required` | `reason` missing/blank |
| `You cannot reject your own transaction` | checker id == transaction creator id |
| `Transaction is not pending single-level approval` | wrong status for a single-level transaction |
| `Transaction is not pending approval` | wrong status for a two-level transaction |
| `Transaction has already been processed and is in status: {status}` | transaction already in a terminal state |

**Errors — `404 Not Found`**
| Message | Cause |
|---|---|
| `Transaction not found with id: {id}` | invalid transaction id |
| `User not found with id: {id}` | invalid `checkerId` |
| `User id {id} is not a checker` | `checkerId` belongs to a maker |

---

## 4. Gamification APIs

Gamification service base URL: `http://localhost:8086`

### 4.1 Register Admin
Registers a new admin for an application (for example `bank`).

**Request**
```
POST /api/gamification/admin/register
Content-Type: application/json
```
```json
{
  "name": "Bank Admin",
  "username": "bank-admin",
  "password": "admin123",
  "applicationId": "bank"
}
```

**Response `200 OK`**
```json
{
  "id": 1,
  "name": "Bank Admin",
  "username": "bank-admin",
  "applicationId": "bank",
  "valid": true
}
```

**Errors**
| Status | Cause |
|---|---|
| 400 | missing `name`, `username`, or `password` |
| 400 | username already exists for that application |

---

### 4.2 Admin Login
Validates an admin account for the selected application.

**Request**
```
POST /api/gamification/admin/login
Content-Type: application/json
```
```json
{
  "username": "bank-admin",
  "password": "admin123",
  "applicationId": "bank"
}
```

**Response `200 OK`**
```json
{
  "valid": true,
  "username": "bank-admin",
  "applicationId": "bank"
}
```

**Errors**
| Status | Cause |
|---|---|
| 200 | invalid credentials returns `{ "valid": false, ... }` |

---

### 4.3 Get Points-to-Amount Conversion Rate
Gets the current conversion rate configured by the admin.

**Request**
```
GET /api/gamification/points-rate/bank
```

**Response `200 OK`**
```json
{
  "applicationId": "bank",
  "pointsPerRupee": 100,
  "description": "100 points = 1 rupee"
}
```

**Default value**
- `pointsPerRupee = 100`
- This means `100 points = ₹1`

---

### 4.4 Update Points-to-Amount Conversion Rate
Bank admin can dynamically change how many points equal one rupee.

**Request**
```
PUT /api/gamification/points-rate/bank
Content-Type: application/json
```
```json
{
  "pointsPerRupee": 50
}
```

**Response `200 OK`**
```json
{
  "applicationId": "bank",
  "pointsPerRupee": 50,
  "description": "100 points = 1 rupee"
}
```

**Notes**
- `pointsPerRupee` must be greater than zero.
- Example: `50 points = ₹1` when set to `50`.

---

### 4.5 Trigger Gamification Event
Publishes a reward event for a user, such as `TRANSACTION_COMPLETED`, `USER_REFERRED`, or custom badge conditions.

**Request**
```
POST /api/gamification/event
Content-Type: application/json
```
```json
{
  "applicationId": "bank",
  "eventName": "TRANSACTION_COMPLETED",
  "userId": 1,
  "context": {
    "amount": 5000,
    "debitAccountId": 1,
    "beneficiaryAccountId": 2
  }
}
```

**Response `200 OK`**
```json
{}
```

**Notes**
- The response is empty on success.
- If the event has no matching active rule, it is ignored.

---

### 4.6 Get User Gamification Profile
Gets a user's current rewards profile for a specific application.

**Gamification service request**
```
GET /api/gamification/profile/{userId}/{applicationId}
```
Example:
```
GET /api/gamification/profile/1/bank
```

**Bank service passthrough request**
```
GET /api/gamification/profile/{userId}
```
Example:
```
GET /api/gamification/profile/1
```

The bank service reads the user ID from the caller and internally calls the gamification service with `applicationId=bank`.

**Response `200 OK`**
```json
{
  "id": 1,
  "userId": 1,
  "applicationId": "bank",
  "totalPoints": 250.00,
  "currentLevel": 1,
  "totalBadges": 2,
  "updatedAt": "2026-08-17T12:10:30"
}
```

---

### 4.7 View Reward Rules
Returns the active event rules for an application.

**Request**
```
GET /api/gamification/rules?applicationId=bank
```

**Response `200 OK`**
```json
[
  {
    "id": 1,
    "eventName": "USER_REFERRED",
    "rewardType": "POINTS",
    "rewardValue": 100,
    "status": "ACTIVE",
    "applicationId": "bank",
    "description": "Referral reward"
  }
]
```

---

### 4.8 User Reward History
Returns reward activity for a user.

**Request**
```
GET /api/gamification/history/{userId}?applicationId=bank
```

**Response `200 OK`**
```json
[
  {
    "id": 10,
    "userId": 1,
    "applicationId": "bank",
    "eventName": "TRANSACTION_COMPLETED",
    "rewardType": "POINTS",
    "rewardValue": 25,
    "source": "event:TRANSACTION_COMPLETED",
    "awardedAt": "2026-08-17T10:30:00"
  }
]
```

---

## 5. Points Redemption and Account Balance Top-Up

This is the newly added feature.

### 5.1 Redeem Points into Amount and Add to Balance
Converts points into rupees using the configured conversion rate, then adds the corresponding amount to the maker's account balance.

**Request**
```
POST /api/makers/{makerId}/redeem-points
Content-Type: application/json
```
```json
{
  "pointsToRedeem": 500
}
```

**If points rate is `100`**
- `500 points = ₹5`
- the bank adds `₹5.00` to the maker's account balance

**Response `200 OK`**
```json
{
  "userId": 1,
  "pointsRedeemed": 500,
  "amount": 5.00,
  "balanceAfterRedemption": 100005.00,
  "remainingPoints": 250.00,
  "pointsPerRupee": 100
}
```

**Validation / error cases**
| Status | Cause |
|---|---|
| 400 | `pointsToRedeem` missing or <= 0 |
| 400 | user does not have enough points |
| 404 | maker not found |
| 404 | account not found for maker |

**Example failure**
```json
{
  "timestamp": "2026-08-17T12:45:00",
  "status": 400,
  "error": "Bad Request",
  "message": "Insufficient points balance to redeem"
}
```

---

### 5.2 Points Redemption Flow in Gamification Service
The gamification service internally performs:
- look up the user's current points
- validate enough points exist
- read `pointsPerRupee` from application settings
- calculate `amount = points / pointsPerRupee`
- subtract redeemed points from the profile
- record a reward ledger entry
- return the amount and remaining points

**Example internal response**
```json
{
  "userId": 1,
  "pointsRedeemed": 500,
  "amount": 5.00,
  "remainingPoints": 250.00,
  "pointsPerRupee": 100
}
```

---

## 6. Status & Action Reference

### Transaction Status (`status`)
| Status | Meaning |
|---|---|
| `PENDING_APPROVAL_L1` | Waiting for level-1 checker (or the only checker, for single-level) |
| `PENDING_APPROVAL_L2` | Waiting for level-2 checker (two-level transfers only) |
| `APPROVED` | Fully approved, about to execute |
| `PROCESSING` | Execution in progress |
| `SUCCESS` | Funds moved successfully (terminal) |
| `FAILED` | Execution failed, e.g. balance dropped before settlement (terminal) |
| `REJECTED` | Rejected by a checker (terminal) |

### Approval Log Action (`action`)
| Action | Meaning |
|---|---|
| `CREATED` | Maker created the transaction |
| `APPROVED_L1` | Approved at level 1 (two-level flow) |
| `APPROVED_L2` | Approved at level 2 — final approval (two-level flow) |
| `REJECTED_L1` | Rejected at level 1 — terminal (two-level flow) |
| `REJECTED_L2` | Rejected at level 2 (two-level flow) |
| `SENT_BACK_L1` | Logged alongside `REJECTED_L2` — transaction re-queued to level 1 |
| `APPROVED_SINGLE` | Approved — final (single-level flow, amount ≤ 10000) |
| `REJECTED_SINGLE` | Rejected — terminal (single-level flow, amount ≤ 10000) |
| `EXECUTION_FAILED` | Fully approved but settlement failed at execution time |

### Business Rules Summary
- Amount > ₹10,000 → 2-level approval required. Amount ≤ ₹10,000 → single-level.
- Maker gets an account (₹1,00,000 default balance) on creation; Checker does not.
- Only a Maker id can create a transaction; only a Checker id can approve/reject.
- A user cannot approve/reject their own transaction.
- No action allowed on a transaction already in a terminal state (`SUCCESS`, `FAILED`, `REJECTED`).
- Rejection always requires a `reason`.
- Duplicate pending requests (same debit account + beneficiary + amount, still pending, within 5 minutes) are blocked.
