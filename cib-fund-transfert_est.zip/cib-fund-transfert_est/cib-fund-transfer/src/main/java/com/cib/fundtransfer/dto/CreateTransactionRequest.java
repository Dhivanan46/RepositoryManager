package com.cib.fundtransfer.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CreateTransactionRequest {

    @NotNull(message = "makerId is required")
    private Long makerId; // userId of the maker creating the transaction (acts as identity, no login)

    @NotNull(message = "beneficiaryUserId is required")
    private Long beneficiaryUserId; // userId of the other maker being paid

    @NotNull(message = "amount is required")
    @DecimalMin(value = "0.01", message = "amount must be greater than zero")
    private BigDecimal amount;
}
