package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.TxnStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
public class TransactionResponse {
    private Long transactionId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String debitAccountNumber;
    private String beneficiaryAccountNumber;
    private BigDecimal amount;
    private String type; // DEBIT (from maker's perspective) - kept simple, single row per transfer
    private TxnStatus status;
    private boolean twoLevelApprovalRequired;
    private Long createdBy;
    private String approvedByLevel1Name;
    private String approvedByLevel2Name;
    private String lastRejectionReason;
}
