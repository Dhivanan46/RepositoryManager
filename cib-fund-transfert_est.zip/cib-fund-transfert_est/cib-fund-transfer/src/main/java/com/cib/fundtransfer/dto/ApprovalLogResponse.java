package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.ApprovalAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
public class ApprovalLogResponse {
    private Long transactionId;
    private ApprovalAction action;
    private Long actionBy;
    private String reason;
    private LocalDateTime actedAt;
}
