package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.dto.CheckerActionHistoryResponse;
import com.cib.fundtransfer.dto.CheckerResponse;
import com.cib.fundtransfer.dto.CreateUserRequest;
import com.cib.fundtransfer.dto.TransactionResponse;
import com.cib.fundtransfer.service.ApprovalService;
import com.cib.fundtransfer.service.CheckerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/checkers")
@RequiredArgsConstructor
public class CheckerController {

    private final CheckerService checkerService;
    private final ApprovalService approvalService;

    // checkers have NO account - they only exist to approve/reject
    @PostMapping
    public ResponseEntity<CheckerResponse> createChecker(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(checkerService.createChecker(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CheckerResponse> getChecker(@PathVariable Long id) {
        return ResponseEntity.ok(checkerService.getChecker(id));
    }

    @GetMapping("/{id}/pending-transactions")
    public ResponseEntity<List<TransactionResponse>> getPending(@PathVariable Long id) {
        return ResponseEntity.ok(approvalService.getPendingForChecker(id));
    }

    @GetMapping("/{id}/action-history")
    public ResponseEntity<List<CheckerActionHistoryResponse>> getActionHistory(@PathVariable Long id) {
        return ResponseEntity.ok(checkerService.getCheckerActionHistory(id));
    }
}
