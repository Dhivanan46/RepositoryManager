package com.cib.fundtransfer.entity;

import com.cib.fundtransfer.enums.TxnStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long debitAccountId;

    @Column(nullable = false)
    private Long beneficiaryAccountId;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TxnStatus status;

    @Column(nullable = false)
    private boolean twoLevelApprovalRequired;

    @Column(nullable = false)
    private Long createdBy; // maker userId

    private Long approvedByLevel1; // checker userId who approved level 1

    private Long approvedByLevel2; // checker userId who approved level 2 (final approver)

    private String lastRejectionReason;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
