package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.dto.CreateUserRequest;
import com.cib.fundtransfer.dto.MakerResponse;
import com.cib.fundtransfer.service.MakerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/makers")
@RequiredArgsConstructor
public class MakerController {

    private final MakerService makerService;

    // create maker -> auto-creates account with default balance of 1 lakh
    @PostMapping
    public ResponseEntity<MakerResponse> createMaker(@Valid @RequestBody CreateUserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(makerService.createMaker(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<MakerResponse> getMaker(@PathVariable Long id) {
        return ResponseEntity.ok(makerService.getMaker(id));
    }

    // list all other makers as potential beneficiaries
    @GetMapping("/{id}/beneficiaries")
    public ResponseEntity<List<MakerResponse>> getBeneficiaries(@PathVariable Long id) {
        return ResponseEntity.ok(makerService.getBeneficiaries(id));
    }
}
