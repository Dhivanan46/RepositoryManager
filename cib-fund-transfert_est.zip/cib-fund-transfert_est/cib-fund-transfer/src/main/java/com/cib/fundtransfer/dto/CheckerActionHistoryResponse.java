package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.ApprovalAction;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
public class CheckerActionHistoryResponse {
    private Long transactionId;
    private String debitAccountNumber;
    private String beneficiaryAccountNumber;
    private BigDecimal amount;
    private ApprovalAction action;
    private String reason;
    private LocalDateTime actedAt;
}
