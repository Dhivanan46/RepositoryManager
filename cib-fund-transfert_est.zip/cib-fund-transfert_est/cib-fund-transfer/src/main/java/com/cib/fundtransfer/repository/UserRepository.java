package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    List<User> findByRole(Role role);
}
