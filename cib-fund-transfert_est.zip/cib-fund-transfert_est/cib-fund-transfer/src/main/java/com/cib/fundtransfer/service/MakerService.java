package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.CreateUserRequest;
import com.cib.fundtransfer.dto.MakerResponse;
import com.cib.fundtransfer.dto.PointsRedemptionResponse;
import com.cib.fundtransfer.entity.Account;
import com.cib.fundtransfer.entity.Referral;
import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.Role;
import com.cib.fundtransfer.exception.BusinessException;
import com.cib.fundtransfer.exception.ResourceNotFoundException;
import com.cib.fundtransfer.integration.GamificationEventPublisher;
import com.cib.fundtransfer.repository.AccountRepository;
import com.cib.fundtransfer.repository.ReferralRepository;
import com.cib.fundtransfer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MakerService {

    private static final BigDecimal DEFAULT_BALANCE = new BigDecimal("100000.00");

    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final ReferralRepository referralRepository;
    private final GamificationEventPublisher gamificationEventPublisher;

    @Transactional
    public MakerResponse createMaker(CreateUserRequest request) {
        User maker = new User();
        maker.setName(request.getName());
        maker.setRole(Role.MAKER);
        maker = userRepository.save(maker);

        if (request.getReferralId() != null && !request.getReferralId().isBlank()) {
            Long referrerUserId = parseReferralId(request.getReferralId());
            User referrer = userRepository.findById(referrerUserId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + referrerUserId));
            if (referrer.getRole() != Role.MAKER) {
                throw new BusinessException("User id " + referrerUserId + " is not a maker");
            }

            Referral referral = new Referral();
            referral.setMakerUserId(maker.getId());
            referral.setReferredByUserId(referrer.getId());
            referralRepository.save(referral);

            // Emit gamification event for referral
            gamificationEventPublisher.publishUserReferred(maker.getId(), referrerUserId);
        }

        Account account = new Account();
        account.setUserId(maker.getId());
        account.setAccountNumber(generateAccountNumber(maker.getId()));
        account.setBalance(DEFAULT_BALANCE);
        account = accountRepository.save(account);

        return toResponse(maker, account);
    }

    public MakerResponse getMaker(Long makerId) {
        User maker = getMakerUser(makerId);
        Account account = accountRepository.findByUserId(makerId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found for maker id: " + makerId));
        return toResponse(maker, account);
    }

    // returns all other makers as potential beneficiaries (excludes self, excludes checkers)
    public List<MakerResponse> getBeneficiaries(Long makerId) {
        getMakerUser(makerId); // validates the maker exists
        return userRepository.findByRole(Role.MAKER).stream()
                .filter(u -> !u.getId().equals(makerId))
                .map(u -> {
                    Account acc = accountRepository.findByUserId(u.getId())
                            .orElseThrow(() -> new ResourceNotFoundException("Account not found for maker id: " + u.getId()));
                    return toResponse(u, acc);
                })
                .toList();
    }

    public User getMakerUser(Long makerId) {
        User user = userRepository.findById(makerId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + makerId));
        if (user.getRole() != Role.MAKER) {
            throw new ResourceNotFoundException("User id " + makerId + " is not a maker");
        }
        return user;
    }

    @Transactional
    public PointsRedemptionResponse redeemPoints(Long makerId, BigDecimal pointsToRedeem) {
        User user = getMakerUser(makerId);
        Account account = accountRepository.findByUserId(makerId)
                .orElseThrow(() -> new ResourceNotFoundException("Account not found for maker id: " + makerId));

        var redemptionDetails = gamificationEventPublisher.redeemPoints(makerId, pointsToRedeem, "bank");
        BigDecimal pointsRedeemed = new BigDecimal(redemptionDetails.get("pointsRedeemed").toString());
        BigDecimal amount = new BigDecimal(redemptionDetails.get("amount").toString());
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("Redeemed points produced no amount");
        }

        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);

        return new PointsRedemptionResponse(
                user.getId(),
                pointsRedeemed,
                amount,
                account.getBalance(),
                redemptionDetails.get("remainingPoints") != null ? new BigDecimal(redemptionDetails.get("remainingPoints").toString()) : BigDecimal.ZERO,
                redemptionDetails.get("pointsPerRupee") != null ? new BigDecimal(redemptionDetails.get("pointsPerRupee").toString()) : BigDecimal.ZERO
        );
    }

    private Long parseReferralId(String referralId) {
        try {
            return Long.parseLong(referralId.trim());
        } catch (NumberFormatException ex) {
            throw new BusinessException("Referral id must be a valid numeric user id");
        }
    }

    private String generateAccountNumber(Long userId) {
        return "AC" + String.format("%010d", userId);
    }

    private MakerResponse toResponse(User user, Account account) {
        return new MakerResponse(user.getId(), user.getName(), account.getId(), account.getAccountNumber(), account.getBalance());
    }
}
