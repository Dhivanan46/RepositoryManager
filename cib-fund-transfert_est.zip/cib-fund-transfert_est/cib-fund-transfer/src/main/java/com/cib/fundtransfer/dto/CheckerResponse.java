package com.cib.fundtransfer.dto;

import com.cib.fundtransfer.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
public class CheckerResponse {
    private Long userId;
    private String name;
    private Role role;
    private LocalDateTime createdAt;
}
