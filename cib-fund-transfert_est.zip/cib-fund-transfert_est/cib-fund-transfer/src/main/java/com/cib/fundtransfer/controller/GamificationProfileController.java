package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.integration.GamificationEventPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class GamificationProfileController {

    private final GamificationEventPublisher gamificationEventPublisher;

    @GetMapping("/gamification/profile/{userId}")
    public ResponseEntity<Map<String, Object>> getGamificationProfile(@PathVariable Long userId) {
        return ResponseEntity.ok(gamificationEventPublisher.getUserProfile(userId, "bank"));
    }
}
