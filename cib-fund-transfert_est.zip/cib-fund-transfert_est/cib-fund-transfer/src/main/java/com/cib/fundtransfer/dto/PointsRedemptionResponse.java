package com.cib.fundtransfer.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PointsRedemptionResponse {
    private Long userId;
    private BigDecimal pointsRedeemed;
    private BigDecimal amount;
    private BigDecimal balanceAfterRedemption;
    private BigDecimal remainingPoints;
    private BigDecimal pointsPerRupee;
}
