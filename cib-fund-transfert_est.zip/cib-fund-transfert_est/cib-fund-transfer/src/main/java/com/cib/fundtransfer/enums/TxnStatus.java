package com.cib.fundtransfer.enums;

public enum TxnStatus {
    PENDING_APPROVAL_L1,   // waiting for level-1 checker
    PENDING_APPROVAL_L2,   // waiting for level-2 checker (only when amount > 10000)
    APPROVED,              // fully approved, about to be executed
    PROCESSING,            // execution in progress (debit/credit)
    SUCCESS,               // money moved successfully
    FAILED,                // execution failed (e.g. insufficient balance at execution time)
    REJECTED               // rejected by a checker, terminal
}
