package com.cib.fundtransfer.enums;

public enum TxnType {
    DEBIT,
    CREDIT
}
