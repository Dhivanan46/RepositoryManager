package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.CreateTransactionRequest;
import com.cib.fundtransfer.dto.TransactionResponse;
import com.cib.fundtransfer.entity.Account;
import com.cib.fundtransfer.entity.Transaction;
import com.cib.fundtransfer.entity.TransactionApprovalLog;
import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.ApprovalAction;
import com.cib.fundtransfer.enums.TxnStatus;
import com.cib.fundtransfer.exception.BusinessException;
import com.cib.fundtransfer.exception.ResourceNotFoundException;
import com.cib.fundtransfer.repository.AccountRepository;
import com.cib.fundtransfer.repository.TransactionApprovalLogRepository;
import com.cib.fundtransfer.repository.TransactionRepository;
import com.cib.fundtransfer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionService {

    public static final BigDecimal TWO_LEVEL_APPROVAL_THRESHOLD = new BigDecimal("10000");
    private static final int DUPLICATE_CHECK_WINDOW_MINUTES = 5;

    private final TransactionRepository transactionRepository;
    private final TransactionApprovalLogRepository logRepository;
    private final AccountRepository accountRepository;
    private final UserRepository userRepository;
    private final MakerService makerService;

    @Transactional
    public TransactionResponse createTransaction(CreateTransactionRequest request) {

        // 1. maker must exist and actually be a MAKER (checkers are blocked here automatically)
        User maker = makerService.getMakerUser(request.getMakerId());

        // 2. beneficiary must exist and be a MAKER (not self, not a checker)
        if (request.getBeneficiaryUserId().equals(request.getMakerId())) {
            throw new BusinessException("Maker cannot select their own account as beneficiary");
        }
        User beneficiary = makerService.getMakerUser(request.getBeneficiaryUserId());

        // 3. valid debit account
        Account debitAccount = accountRepository.findByUserId(maker.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Debit account not found for maker id: " + maker.getId()));

        // 4. valid beneficiary account
        Account beneficiaryAccount = accountRepository.findByUserId(beneficiary.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Beneficiary account not found for user id: " + beneficiary.getId()));

        BigDecimal amount = request.getAmount();

        // 5. amount > 0 already enforced by DTO validation, double-check here
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BusinessException("Amount must be greater than zero");
        }

        // 6. sufficient balance at request time
        if (debitAccount.getBalance().compareTo(amount) < 0) {
            throw new BusinessException("Insufficient balance in debit account");
        }

        // 7. duplicate transaction/request check - same debit+beneficiary+amount still pending within window
        LocalDateTime windowStart = LocalDateTime.now().minusMinutes(DUPLICATE_CHECK_WINDOW_MINUTES);
        List<Transaction> duplicates = transactionRepository
                .findByDebitAccountIdAndBeneficiaryAccountIdAndAmountAndStatusInAndCreatedAtAfter(
                        debitAccount.getId(),
                        beneficiaryAccount.getId(),
                        amount,
                        List.of(TxnStatus.PENDING_APPROVAL_L1, TxnStatus.PENDING_APPROVAL_L2),
                        windowStart
                );
        if (!duplicates.isEmpty()) {
            throw new BusinessException("A similar transaction is already pending approval. Duplicate request rejected.");
        }

        // build transaction
        boolean twoLevel = amount.compareTo(TWO_LEVEL_APPROVAL_THRESHOLD) > 0;

        Transaction txn = new Transaction();
        txn.setDebitAccountId(debitAccount.getId());
        txn.setBeneficiaryAccountId(beneficiaryAccount.getId());
        txn.setAmount(amount);
        txn.setStatus(TxnStatus.PENDING_APPROVAL_L1);
        txn.setTwoLevelApprovalRequired(twoLevel);
        txn.setCreatedBy(maker.getId());
        txn = transactionRepository.save(txn);

        // log creation
        TransactionApprovalLog log = new TransactionApprovalLog();
        log.setTransactionId(txn.getId());
        log.setAction(ApprovalAction.CREATED);
        log.setActionBy(maker.getId());
        logRepository.save(log);

        return toResponse(txn);
    }

    public TransactionResponse getTransaction(Long id) {
        Transaction txn = transactionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + id));
        return toResponse(txn);
    }

    public List<TransactionResponse> getHistoryForMaker(Long makerId, TxnStatus statusFilter) {
        makerService.getMakerUser(makerId);
        List<Transaction> txns = statusFilter != null
                ? transactionRepository.findByCreatedByAndStatusOrderByCreatedAtDesc(makerId, statusFilter)
                : transactionRepository.findByCreatedByOrderByCreatedAtDesc(makerId);
        return txns.stream().map(this::toResponse).toList();
    }

    public TransactionResponse toResponse(Transaction txn) {
        String debitAccountNumber = accountRepository.findById(txn.getDebitAccountId())
                .map(Account::getAccountNumber)
                .orElse(null);
        String beneficiaryAccountNumber = accountRepository.findById(txn.getBeneficiaryAccountId())
                .map(Account::getAccountNumber)
                .orElse(null);
        String approvedByLevel1Name = txn.getApprovedByLevel1() != null
                ? userRepository.findById(txn.getApprovedByLevel1()).map(u -> u.getName()).orElse(null)
                : null;
        String approvedByLevel2Name = txn.getApprovedByLevel2() != null
                ? userRepository.findById(txn.getApprovedByLevel2()).map(u -> u.getName()).orElse(null)
                : null;
        return new TransactionResponse(
                txn.getId(),
                txn.getCreatedAt(),
                txn.getUpdatedAt(),
                debitAccountNumber,
                beneficiaryAccountNumber,
                txn.getAmount(),
                "DEBIT",
                txn.getStatus(),
                txn.isTwoLevelApprovalRequired(),
                txn.getCreatedBy(),
                approvedByLevel1Name,
                approvedByLevel2Name,
                txn.getLastRejectionReason()
        );
    }
}
