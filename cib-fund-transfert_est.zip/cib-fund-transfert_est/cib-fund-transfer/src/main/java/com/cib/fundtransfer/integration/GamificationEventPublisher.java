package com.cib.fundtransfer.integration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Publishes gamification events to the external gamification service.
 * This allows the banking application to trigger rewards without tight coupling.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class GamificationEventPublisher {

    @Value("${gamification.service.url:http://localhost:8081}")
    private String gamificationServiceUrl;

    private final RestTemplate restTemplate;

    /**
     * Publishes an event to the gamification service.
     *
     * @param eventName the name of the event (e.g., USER_REFERRED, TRANSACTION_COMPLETED)
     * @param userId    the ID of the user for whom the event occurred
     * @param context   additional context data relevant to the event
     */
    public void publishEvent(String eventName, Long userId, Map<String, Object> context) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("eventName", eventName);
            payload.put("userId", userId);
            payload.put("context", context != null ? context : new HashMap<>());

            String url = gamificationServiceUrl + "/api/gamification/event";
            restTemplate.postForObject(url, payload, Void.class);

            log.info("Gamification event published: eventName={}, userId={}", eventName, userId);
        } catch (RestClientException e) {
            log.warn("Failed to publish gamification event: eventName={}, userId={}, error={}", 
                    eventName, userId, e.getMessage());
            // Do not throw; continue with banking operation even if gamification fails
        } catch (Exception e) {
            log.error("Unexpected error publishing gamification event: eventName={}, userId={}", 
                    eventName, userId, e);
            // Do not throw; continue with banking operation even if gamification fails
        }
    }

    /**
     * Publishes a transaction-completed event.
     */
    public void publishTransactionCompleted(Long makerId, Long amount, Long debitAccountId, Long beneficiaryAccountId) {
        Map<String, Object> context = new HashMap<>();
        context.put("amount", amount);
        context.put("debitAccountId", debitAccountId);
        context.put("beneficiaryAccountId", beneficiaryAccountId);
        publishEvent("TRANSACTION_COMPLETED", makerId, context);
    }

    /**
     * Publishes a user-referred event.
     */
    public void publishUserReferred(Long makerId, Long referredByUserId) {
        Map<String, Object> context = new HashMap<>();
        context.put("referredByUserId", referredByUserId);
        publishEvent("USER_REFERRED", makerId, context);
    }

    public Map<String, Object> redeemPoints(Long userId, BigDecimal pointsToRedeem, String applicationId) {
        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("userId", userId);
            payload.put("pointsToRedeem", pointsToRedeem);
            payload.put("applicationId", applicationId != null ? applicationId : "bank");

            String url = gamificationServiceUrl + "/api/gamification/redeem";
            return restTemplate.postForObject(url, payload, Map.class);
        } catch (RestClientException e) {
            log.warn("Failed to redeem points: userId={}, pointsToRedeem={}, error={}", userId, pointsToRedeem, e.getMessage());
            throw e;
        }
    }

    public Map<String, Object> getPointsRate(String applicationId) {
        try {
            String url = gamificationServiceUrl + "/api/gamification/points-rate/" + (applicationId != null ? applicationId : "bank");
            return restTemplate.getForObject(url, Map.class);
        } catch (RestClientException e) {
            log.warn("Failed to fetch points rate: applicationId={}, error={}", applicationId, e.getMessage());
            throw e;
        }
    }

    public Map<String, Object> getUserProfile(Long userId, String applicationId) {
        try {
            String normalizedApp = applicationId != null && !applicationId.isBlank() ? applicationId : "bank";
            String url = gamificationServiceUrl + "/api/gamification/profile/" + userId + "/" + normalizedApp;
            return restTemplate.getForObject(url, Map.class);
        } catch (RestClientException e) {
            log.warn("Failed to fetch gamification profile: userId={}, applicationId={}, error={}", userId, applicationId, e.getMessage());
            throw e;
        }
    }
}
