package com.cib.fundtransfer.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
public class MakerResponse {
    private Long userId;
    private String name;
    private Long accountId;
    private String accountNumber;
    private BigDecimal balance;
}
