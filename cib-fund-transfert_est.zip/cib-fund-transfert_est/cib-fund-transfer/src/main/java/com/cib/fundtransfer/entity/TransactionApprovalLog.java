package com.cib.fundtransfer.entity;

import com.cib.fundtransfer.enums.ApprovalAction;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "transaction_approval_log")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TransactionApprovalLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long transactionId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ApprovalAction action;

    // userId of the maker (for CREATED) or checker (for approve/reject actions)
    @Column(nullable = false)
    private Long actionBy;

    private String reason; // populated for rejections

    @Column(nullable = false, updatable = false)
    private LocalDateTime actedAt = LocalDateTime.now();
}
