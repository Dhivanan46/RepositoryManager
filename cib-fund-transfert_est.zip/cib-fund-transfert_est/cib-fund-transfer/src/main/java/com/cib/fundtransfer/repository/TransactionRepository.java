package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.Transaction;
import com.cib.fundtransfer.enums.TxnStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findByCreatedByOrderByCreatedAtDesc(Long createdBy);

    List<Transaction> findByCreatedByAndStatusOrderByCreatedAtDesc(Long createdBy, TxnStatus status);

    List<Transaction> findByStatusOrderByCreatedAtAsc(TxnStatus status);

    // duplicate-check: same debit account, same beneficiary, same amount, still pending, created recently
    List<Transaction> findByDebitAccountIdAndBeneficiaryAccountIdAndAmountAndStatusInAndCreatedAtAfter(
            Long debitAccountId,
            Long beneficiaryAccountId,
            BigDecimal amount,
            List<TxnStatus> statuses,
            LocalDateTime after
    );
}
