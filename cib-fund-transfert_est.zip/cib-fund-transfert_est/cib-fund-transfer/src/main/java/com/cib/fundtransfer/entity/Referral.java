package com.cib.fundtransfer.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "referrals",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_referrals_maker_user_id", columnNames = "maker_user_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Referral {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "maker_user_id", nullable = false, unique = true)
    private Long makerUserId;

    @Column(name = "referrer_user_id", nullable = false)
    private Long referredByUserId;
}
