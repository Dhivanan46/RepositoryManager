package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.dto.PointsRedemptionResponse;
import com.cib.fundtransfer.service.MakerService;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PointsRedemptionController {

    private final MakerService makerService;

    @PostMapping("/makers/{makerId}/redeem-points")
    public ResponseEntity<PointsRedemptionResponse> redeemPoints(
            @PathVariable Long makerId,
            @RequestBody RedeemPointsRequest request) {
        return ResponseEntity.ok(makerService.redeemPoints(makerId, request.getPointsToRedeem()));
    }

    public static class RedeemPointsRequest {
        @NotNull(message = "pointsToRedeem is required")
        @DecimalMin(value = "0.01", inclusive = true, message = "pointsToRedeem must be greater than zero")
        private BigDecimal pointsToRedeem;

        public BigDecimal getPointsToRedeem() {
            return pointsToRedeem;
        }

        public void setPointsToRedeem(BigDecimal pointsToRedeem) {
            this.pointsToRedeem = pointsToRedeem;
        }
    }
}
