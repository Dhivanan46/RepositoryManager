package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.Referral;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReferralRepository extends JpaRepository<Referral, Long> {
}
