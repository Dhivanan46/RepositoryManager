package com.cib.fundtransfer.repository;

import com.cib.fundtransfer.entity.TransactionApprovalLog;
import com.cib.fundtransfer.enums.ApprovalAction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionApprovalLogRepository extends JpaRepository<TransactionApprovalLog, Long> {
    List<TransactionApprovalLog> findByTransactionIdOrderByActedAtAsc(Long transactionId);
    List<TransactionApprovalLog> findByActionByAndActionNotOrderByActedAtDesc(Long actionBy, ApprovalAction excludeAction);
}
