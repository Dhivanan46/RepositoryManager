package com.cib.fundtransfer.enums;

public enum Role {
    MAKER,
    CHECKER
}
