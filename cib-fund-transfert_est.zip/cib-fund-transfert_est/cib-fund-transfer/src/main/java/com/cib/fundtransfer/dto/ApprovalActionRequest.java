package com.cib.fundtransfer.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApprovalActionRequest {

    @NotNull(message = "checkerId is required")
    private Long checkerId;

    // required only for reject; optional for approve
    private String reason;
}
