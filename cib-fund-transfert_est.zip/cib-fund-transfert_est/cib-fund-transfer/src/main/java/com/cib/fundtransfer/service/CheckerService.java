package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.CheckerActionHistoryResponse;
import com.cib.fundtransfer.dto.CheckerResponse;
import com.cib.fundtransfer.dto.CreateUserRequest;
import com.cib.fundtransfer.entity.Account;
import com.cib.fundtransfer.entity.Transaction;
import com.cib.fundtransfer.entity.TransactionApprovalLog;
import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.ApprovalAction;
import com.cib.fundtransfer.enums.Role;
import com.cib.fundtransfer.exception.ResourceNotFoundException;
import com.cib.fundtransfer.repository.AccountRepository;
import com.cib.fundtransfer.repository.TransactionApprovalLogRepository;
import com.cib.fundtransfer.repository.TransactionRepository;
import com.cib.fundtransfer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CheckerService {

    private final UserRepository userRepository;
    private final TransactionApprovalLogRepository logRepository;
    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public CheckerResponse createChecker(CreateUserRequest request) {
        User checker = new User();
        checker.setName(request.getName());
        checker.setRole(Role.CHECKER);
        checker = userRepository.save(checker);
        return toResponse(checker);
    }

    public CheckerResponse getChecker(Long checkerId) {
        return toResponse(getCheckerUser(checkerId));
    }

    public List<CheckerActionHistoryResponse> getCheckerActionHistory(Long checkerId) {
        getCheckerUser(checkerId); // validates checker exists and is a CHECKER
        return logRepository.findByActionByAndActionNotOrderByActedAtDesc(checkerId, ApprovalAction.CREATED)
                .stream()
                .map(this::toActionHistoryResponse)
                .toList();
    }

    private CheckerActionHistoryResponse toActionHistoryResponse(TransactionApprovalLog log) {
        Transaction txn = transactionRepository.findById(log.getTransactionId())
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + log.getTransactionId()));
        String debitAccountNumber = accountRepository.findById(txn.getDebitAccountId())
                .map(Account::getAccountNumber).orElse(null);
        String beneficiaryAccountNumber = accountRepository.findById(txn.getBeneficiaryAccountId())
                .map(Account::getAccountNumber).orElse(null);
        return new CheckerActionHistoryResponse(
                txn.getId(),
                debitAccountNumber,
                beneficiaryAccountNumber,
                txn.getAmount(),
                log.getAction(),
                log.getReason(),
                log.getActedAt()
        );
    }

    public User getCheckerUser(Long checkerId) {
        User user = userRepository.findById(checkerId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + checkerId));
        if (user.getRole() != Role.CHECKER) {
            throw new ResourceNotFoundException("User id " + checkerId + " is not a checker");
        }
        return user;
    }

    private CheckerResponse toResponse(User checker) {
        return new CheckerResponse(checker.getId(), checker.getName(), checker.getRole(), checker.getCreatedAt());
    }
}
