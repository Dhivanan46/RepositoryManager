package com.cib.fundtransfer.enums;

public enum ApprovalAction {
    CREATED,        // transaction created by maker
    APPROVED_L1,    // approved at level 1
    APPROVED_L2,    // approved at level 2 (final)
    REJECTED_L1,    // rejected at level 1 (terminal)
    REJECTED_L2,    // rejected at level 2 -> sent back to level 1
    SENT_BACK_L1,   // re-entered level 1 queue after L2 rejection
    APPROVED_SINGLE,// single-level approval (amount <= 10000)
    REJECTED_SINGLE,// single-level rejection (amount <= 10000)
    EXECUTION_FAILED // fully approved but settlement failed (e.g. balance dropped before execution)
}
