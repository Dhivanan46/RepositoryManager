package com.cib.fundtransfer.controller;

import com.cib.fundtransfer.dto.ApprovalActionRequest;
import com.cib.fundtransfer.dto.ApprovalLogResponse;
import com.cib.fundtransfer.dto.CreateTransactionRequest;
import com.cib.fundtransfer.dto.TransactionResponse;
import com.cib.fundtransfer.enums.TxnStatus;
import com.cib.fundtransfer.service.ApprovalService;
import com.cib.fundtransfer.service.TransactionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;
    private final ApprovalService approvalService;

    // create fund transfer request - only a MAKER (never a checker) can call this;
    // TransactionService resolves makerId via MakerService which rejects non-maker ids
    @PostMapping
    public ResponseEntity<TransactionResponse> createTransaction(@Valid @RequestBody CreateTransactionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(transactionService.createTransaction(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionResponse> getTransaction(@PathVariable Long id) {
        return ResponseEntity.ok(transactionService.getTransaction(id));
    }

    // transaction history for a maker, optional status filter
    @GetMapping("/maker/{makerId}")
    public ResponseEntity<List<TransactionResponse>> getHistory(
            @PathVariable Long makerId,
            @RequestParam(required = false) TxnStatus status) {
        return ResponseEntity.ok(transactionService.getHistoryForMaker(makerId, status));
    }

    // full detailed approval flow/timeline for a transaction
    @GetMapping("/{id}/flow")
    public ResponseEntity<List<ApprovalLogResponse>> getFlow(@PathVariable Long id) {
        return ResponseEntity.ok(approvalService.getFlow(id));
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<TransactionResponse> approve(@PathVariable Long id, @Valid @RequestBody ApprovalActionRequest request) {
        return ResponseEntity.ok(approvalService.approve(id, request));
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<TransactionResponse> reject(@PathVariable Long id, @Valid @RequestBody ApprovalActionRequest request) {
        return ResponseEntity.ok(approvalService.reject(id, request));
    }
}
