package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.ApprovalActionRequest;
import com.cib.fundtransfer.dto.ApprovalLogResponse;
import com.cib.fundtransfer.dto.TransactionResponse;
import com.cib.fundtransfer.entity.Account;
import com.cib.fundtransfer.entity.Transaction;
import com.cib.fundtransfer.entity.TransactionApprovalLog;
import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.ApprovalAction;
import com.cib.fundtransfer.enums.TxnStatus;
import com.cib.fundtransfer.exception.BusinessException;
import com.cib.fundtransfer.exception.ResourceNotFoundException;
import com.cib.fundtransfer.integration.GamificationEventPublisher;
import com.cib.fundtransfer.repository.AccountRepository;
import com.cib.fundtransfer.repository.TransactionApprovalLogRepository;
import com.cib.fundtransfer.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class ApprovalService {

    private final TransactionRepository transactionRepository;
    private final TransactionApprovalLogRepository logRepository;
    private final AccountRepository accountRepository;
    private final CheckerService checkerService;
    private final TransactionService transactionService;
    private final GamificationEventPublisher gamificationEventPublisher;

    private static final List<TxnStatus> PENDING_STATUSES =
            List.of(TxnStatus.PENDING_APPROVAL_L1, TxnStatus.PENDING_APPROVAL_L2);

    // combined inbox: both level-1 and level-2 pending items, excluding the checker's own (won't happen, but defensive)
    public List<TransactionResponse> getPendingForChecker(Long checkerId) {
        checkerService.getCheckerUser(checkerId);
        List<Transaction> l1 = transactionRepository.findByStatusOrderByCreatedAtAsc(TxnStatus.PENDING_APPROVAL_L1);
        List<Transaction> l2 = transactionRepository.findByStatusOrderByCreatedAtAsc(TxnStatus.PENDING_APPROVAL_L2);
        return Stream.concat(l1.stream(), l2.stream())
                .filter(t -> !t.getCreatedBy().equals(checkerId))
                .map(transactionService::toResponse)
                .toList();
    }

    @Transactional
    public TransactionResponse approve(Long transactionId, ApprovalActionRequest request) {
        Transaction txn = getTransactionForAction(transactionId);
        User checker = checkerService.getCheckerUser(request.getCheckerId());

        // maker cannot approve their own transaction (defensive; role separation already prevents this)
        if (txn.getCreatedBy().equals(checker.getId())) {
            throw new BusinessException("You cannot approve your own transaction");
        }

        if (!txn.isTwoLevelApprovalRequired()) {
            // single-level approval
            if (txn.getStatus() != TxnStatus.PENDING_APPROVAL_L1) {
                throw new BusinessException("Transaction is not pending single-level approval");
            }
            txn.setApprovedByLevel1(checker.getId());
            txn.setStatus(TxnStatus.APPROVED);
            addLog(transactionId, ApprovalAction.APPROVED_SINGLE, checker.getId(), null);
        } else {
            if (txn.getStatus() == TxnStatus.PENDING_APPROVAL_L1) {
                txn.setApprovedByLevel1(checker.getId());
                txn.setStatus(TxnStatus.PENDING_APPROVAL_L2);
                addLog(transactionId, ApprovalAction.APPROVED_L1, checker.getId(), null);
                transactionRepository.save(txn);
                return transactionService.toResponse(txn);
            } else if (txn.getStatus() == TxnStatus.PENDING_APPROVAL_L2) {
                txn.setApprovedByLevel2(checker.getId());
                txn.setStatus(TxnStatus.APPROVED);
                addLog(transactionId, ApprovalAction.APPROVED_L2, checker.getId(), null);
            } else {
                throw new BusinessException("Transaction is not pending approval");
            }
        }

        transactionRepository.save(txn);
        return execute(txn);
    }

    @Transactional
    public TransactionResponse reject(Long transactionId, ApprovalActionRequest request) {
        if (request.getReason() == null || request.getReason().isBlank()) {
            throw new BusinessException("Rejection reason is required");
        }

        Transaction txn = getTransactionForAction(transactionId);
        User checker = checkerService.getCheckerUser(request.getCheckerId());

        if (txn.getCreatedBy().equals(checker.getId())) {
            throw new BusinessException("You cannot reject your own transaction");
        }

        if (!txn.isTwoLevelApprovalRequired()) {
            if (txn.getStatus() != TxnStatus.PENDING_APPROVAL_L1) {
                throw new BusinessException("Transaction is not pending single-level approval");
            }
            txn.setStatus(TxnStatus.REJECTED);
            txn.setLastRejectionReason(request.getReason());
            addLog(transactionId, ApprovalAction.REJECTED_SINGLE, checker.getId(), request.getReason());
        } else {
            if (txn.getStatus() == TxnStatus.PENDING_APPROVAL_L1) {
                // straight rejection at level 1 - terminal
                txn.setStatus(TxnStatus.REJECTED);
                txn.setLastRejectionReason(request.getReason());
                addLog(transactionId, ApprovalAction.REJECTED_L1, checker.getId(), request.getReason());
            } else if (txn.getStatus() == TxnStatus.PENDING_APPROVAL_L2) {
                // rejected at level 2 -> sent back to level 1 for re-decision, not terminal
                txn.setStatus(TxnStatus.PENDING_APPROVAL_L1);
                txn.setLastRejectionReason(request.getReason());
                addLog(transactionId, ApprovalAction.REJECTED_L2, checker.getId(), request.getReason());
                addLog(transactionId, ApprovalAction.SENT_BACK_L1, checker.getId(), request.getReason());
            } else {
                throw new BusinessException("Transaction is not pending approval");
            }
        }

        transactionRepository.save(txn);
        return transactionService.toResponse(txn);
    }

    public List<ApprovalLogResponse> getFlow(Long transactionId) {
        // validates the transaction exists
        transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + transactionId));
        return logRepository.findByTransactionIdOrderByActedAtAsc(transactionId).stream()
                .map(l -> new ApprovalLogResponse(l.getTransactionId(), l.getAction(), l.getActionBy(), l.getReason(), l.getActedAt()))
                .toList();
    }

    // executes the fund movement once a transaction reaches APPROVED
    private TransactionResponse execute(Transaction txn) {
        txn.setStatus(TxnStatus.PROCESSING);
        transactionRepository.save(txn);

        Account debitAccount = accountRepository.findById(txn.getDebitAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Debit account not found"));
        Account beneficiaryAccount = accountRepository.findById(txn.getBeneficiaryAccountId())
                .orElseThrow(() -> new ResourceNotFoundException("Beneficiary account not found"));

        if (debitAccount.getBalance().compareTo(txn.getAmount()) < 0) {
            txn.setStatus(TxnStatus.FAILED);
            transactionRepository.save(txn);
            addLog(txn.getId(), ApprovalAction.EXECUTION_FAILED, txn.getApprovedByLevel2() != null ? txn.getApprovedByLevel2() : txn.getApprovedByLevel1(), "Execution failed: insufficient balance");
            return transactionService.toResponse(txn);
        }

        debitAccount.setBalance(debitAccount.getBalance().subtract(txn.getAmount()));
        beneficiaryAccount.setBalance(beneficiaryAccount.getBalance().add(txn.getAmount()));
        accountRepository.save(debitAccount);
        accountRepository.save(beneficiaryAccount);

        txn.setStatus(TxnStatus.SUCCESS);
        transactionRepository.save(txn);

        // Emit gamification event for successful transaction
        gamificationEventPublisher.publishTransactionCompleted(
                txn.getCreatedBy(),
                txn.getAmount().longValue(),
                txn.getDebitAccountId(),
                txn.getBeneficiaryAccountId()
        );

        return transactionService.toResponse(txn);
    }

    private Transaction getTransactionForAction(Long transactionId) {
        Transaction txn = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found with id: " + transactionId));
        if (!PENDING_STATUSES.contains(txn.getStatus())) {
            throw new BusinessException("Transaction has already been processed and is in status: " + txn.getStatus());
        }
        return txn;
    }

    private void addLog(Long transactionId, ApprovalAction action, Long actionBy, String reason) {
        TransactionApprovalLog log = new TransactionApprovalLog();
        log.setTransactionId(transactionId);
        log.setAction(action);
        log.setActionBy(actionBy);
        log.setReason(reason);
        logRepository.save(log);
    }
}
