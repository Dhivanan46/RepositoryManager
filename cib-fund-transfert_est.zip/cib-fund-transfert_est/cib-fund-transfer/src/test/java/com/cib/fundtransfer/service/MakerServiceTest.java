package com.cib.fundtransfer.service;

import com.cib.fundtransfer.dto.CreateUserRequest;
import com.cib.fundtransfer.dto.PointsRedemptionResponse;
import com.cib.fundtransfer.entity.Account;
import com.cib.fundtransfer.entity.User;
import com.cib.fundtransfer.enums.Role;
import com.cib.fundtransfer.integration.GamificationEventPublisher;
import com.cib.fundtransfer.repository.AccountRepository;
import com.cib.fundtransfer.repository.ReferralRepository;
import com.cib.fundtransfer.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MakerServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private ReferralRepository referralRepository;

    @Mock
    private GamificationEventPublisher gamificationEventPublisher;

    @InjectMocks
    private MakerService makerService;

    @Test
    void createMaker_shouldSaveReferralWhenReferralIdProvided() {
        CreateUserRequest request = new CreateUserRequest();
        request.setName("Alice");
        request.setReferralId("1");

        User maker = new User();
        maker.setId(10L);
        maker.setName("Alice");
        maker.setRole(Role.MAKER);

        User referrer = new User();
        referrer.setId(1L);
        referrer.setName("Sponsor");
        referrer.setRole(Role.MAKER);

        Account account = new Account();
        account.setId(99L);
        account.setUserId(10L);
        account.setAccountNumber("AC0000000010");
        account.setBalance(new BigDecimal("100000.00"));

        when(userRepository.save(any(User.class))).thenReturn(maker);
        when(accountRepository.save(any(Account.class))).thenReturn(account);
        when(userRepository.findById(1L)).thenReturn(Optional.of(referrer));

        var response = makerService.createMaker(request);

        assertEquals(10L, response.getUserId());
        verify(referralRepository).save(argThat(referral ->
                referral.getMakerUserId().equals(10L)
                        && referral.getReferredByUserId().equals(1L)
        ));
    }

    @Test
    void redeemPoints_shouldConvertPointsToBalanceUsingCurrentRate() {
        User user = new User();
        user.setId(10L);
        user.setName("Alice");
        user.setRole(Role.MAKER);

        Account account = new Account();
        account.setId(99L);
        account.setUserId(10L);
        account.setAccountNumber("AC0000000010");
        account.setBalance(new BigDecimal("1000.00"));

        when(userRepository.findById(10L)).thenReturn(Optional.of(user));
        when(accountRepository.findByUserId(10L)).thenReturn(Optional.of(account));
        when(gamificationEventPublisher.redeemPoints(10L, new BigDecimal("100.00"), "bank"))
                .thenReturn(Map.of(
                        "userId", 10L,
                        "pointsRedeemed", new BigDecimal("100.00"),
                        "amount", new BigDecimal("1.00"),
                        "remainingPoints", new BigDecimal("0.00"),
                        "pointsPerRupee", new BigDecimal("100.00")
                ));

        PointsRedemptionResponse response = makerService.redeemPoints(10L, new BigDecimal("100.00"));

        assertEquals(new BigDecimal("1.00"), response.getAmount());
        assertEquals(new BigDecimal("1001.00"), account.getBalance());
        verify(accountRepository).save(account);
    }
}
