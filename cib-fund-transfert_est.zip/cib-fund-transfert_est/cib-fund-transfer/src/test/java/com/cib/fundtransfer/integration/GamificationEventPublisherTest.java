package com.cib.fundtransfer.integration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GamificationEventPublisherTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private GamificationEventPublisher gamificationEventPublisher;

    @Test
    void shouldFetchUserProfileUsingApplicationIdInPath() {
        ReflectionTestUtils.setField(gamificationEventPublisher, "gamificationServiceUrl", "http://localhost:8086");
        when(restTemplate.getForObject("http://localhost:8086/api/gamification/profile/7/bank", Map.class))
                .thenReturn(Map.of("userId", 7L, "applicationId", "bank", "totalPoints", 150));

        gamificationEventPublisher.getUserProfile(7L, "bank");

        verify(restTemplate).getForObject("http://localhost:8086/api/gamification/profile/7/bank", Map.class);
    }
}
