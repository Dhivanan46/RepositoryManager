# CIB Fund Transfer - Maker-Checker System

Simple Spring Boot backend (single app, single MySQL DB, no login/JWT/session/CORS).

## Setup

1. Make sure MySQL is running locally. Update `src/main/resources/application.properties` with your MySQL username/password if different from `root/root`. The database `cib_fund_transfer` will be auto-created.
2. Build & run:
   ```
   mvn spring-boot:run
   ```
3. App runs on `http://localhost:8080`.

## Core Rules Implemented

- Creating a Maker auto-creates their Account with a default balance of ₹1,00,000.
- Checkers have **no account** and **cannot create transactions** (enforced: transaction creation requires the caller to resolve as a `MAKER`; checkers fail this check).
- Amount > ₹10,000 → requires 2-level approval. Amount ≤ ₹10,000 → single-level approval.
- Full approval timeline is logged per transaction (`/api/transactions/{id}/flow`), including the level-2-reject → send-back-to-level-1 loop.
- Validations on transfer creation: valid debit account, valid beneficiary (must be another Maker), sufficient balance, amount > 0, no self-transfer, duplicate pending request block (same debit+beneficiary+amount within 5 minutes).
- Validations on approve/reject: only Checkers can act, cannot act on your own transaction, cannot act twice on an already-processed transaction, rejection requires a reason.

## Sample API Walkthrough

### 1. Create two makers
```
POST /api/makers
{ "name": "Alice" }

POST /api/makers
{ "name": "Bob" }
```
Response includes `userId`, `accountId`, `accountNumber`, `balance` (100000.00).

### 2. Create a checker
```
POST /api/checkers
{ "name": "Carol" }
```

### 3. View beneficiaries for Alice
```
GET /api/makers/1/beneficiaries
```

### 4. Alice creates a fund transfer to Bob
```
POST /api/transactions
{ "makerId": 1, "beneficiaryUserId": 2, "amount": 5000 }
```
→ amount ≤ 10000, so status = `PENDING_APPROVAL_L1`.

For amount > 10000, status is still `PENDING_APPROVAL_L1` initially but `twoLevelApprovalRequired = true`, and it needs a second approval after the first.

### 5. Checker views pending queue
```
GET /api/checkers/3/pending-transactions
```

### 6. Checker approves
```
POST /api/transactions/{id}/approve
{ "checkerId": 3 }
```
- If single-level: transaction moves straight to `APPROVED → PROCESSING → SUCCESS/FAILED`.
- If two-level: first approval moves it to `PENDING_APPROVAL_L2`; a second checker must approve again to trigger execution.

### 7. Checker rejects
```
POST /api/transactions/{id}/reject
{ "checkerId": 3, "reason": "Suspicious amount" }
```
- At level 1: terminal `REJECTED`.
- At level 2: sent back to `PENDING_APPROVAL_L1` for level-1 checker to re-approve or reject.

### 8. View full approval flow/timeline
```
GET /api/transactions/{id}/flow
```
Returns every action (`CREATED`, `APPROVED_L1`, `REJECTED_L2`, `SENT_BACK_L1`, etc.) with who did it, when, and any reason.

### 9. Transaction history
```
GET /api/transactions?makerId=1
GET /api/transactions?makerId=1&status=SUCCESS
```

## Status Lifecycle

**Approval (single-level, amount ≤ 10000):**
`PENDING_APPROVAL_L1 → APPROVED → PROCESSING → SUCCESS/FAILED`
`PENDING_APPROVAL_L1 → REJECTED` (terminal)

**Approval (two-level, amount > 10000):**
`PENDING_APPROVAL_L1 → PENDING_APPROVAL_L2 → APPROVED → PROCESSING → SUCCESS/FAILED`
`PENDING_APPROVAL_L1 → REJECTED` (terminal, rejected at level 1)
`PENDING_APPROVAL_L2 → PENDING_APPROVAL_L1` (rejected at level 2, sent back) → then either `PENDING_APPROVAL_L2` again (re-approved) or `REJECTED` (rejected at level 1 after send-back)
