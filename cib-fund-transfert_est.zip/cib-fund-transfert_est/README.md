# CIB Fund Transfer + Gamification System

A modern, plugin-based gamification engine integrated with the CIB Banking application. This system awards points, badges, and rewards based on configurable rules and user activities.

## 🎯 Project Overview

### What is This?
A **generic, plugin-based gamification service** that can be integrated into any application. As a proof-of-concept, it's integrated with the CIB Banking application to:

- Award **points** to users for referrals and successful transactions
- Issue **badges** for achieving milestones (e.g., completing 3 transactions in 7 days)
- Provide a **web dashboard** for users to track their progress and admins to manage rules
- Ensure **no coupling** between banking logic and gamification (event-driven architecture)

### Key Features
✅ **Plugin-Based Architecture** - Add new reward types without modifying core code  
✅ **Data-Driven Rules** - Configure rewards in database, not hardcoded  
✅ **Event-Driven Integration** - Loose coupling via HTTP events  
✅ **Shared Database** - No separate database needed  
✅ **Beautiful Dashboard** - Real-time UI for profiles, rewards, and testing  
✅ **Graceful Degradation** - Banking ops continue if gamification service is down  
✅ **Complete Documentation** - Setup guide, API docs, extension patterns  

---

## 📁 Project Structure

```
cib-fund-transfer/                    # Banking Application (Port 8080)
├── pom.xml
├── src/main/java/com/cib/fundtransfer/
│   ├── controller/                   # REST APIs
│   ├── service/                      # Business logic
│   │   ├── MakerService.java        # ✨ Emits USER_REFERRED event
│   │   ├── ApprovalService.java     # ✨ Emits TRANSACTION_COMPLETED event
│   │   └── ...
│   ├── entity/                       # JPA entities
│   ├── dto/                          # Request/Response objects
│   ├── repository/                   # Database access
│   └── integration/
│       └── GamificationEventPublisher.java  # ✨ NEW: Event publishing to gamification service
├── src/main/resources/
│   └── application.properties        # ✨ MODIFIED: Added gamification.service.url

gamification-service/                 # Gamification Service (Port 8081)
├── pom.xml
├── src/main/java/com/cib/gamification/
│   ├── controller/
│   │   └── GamificationController.java   # REST API endpoints
│   ├── service/
│   │   └── GamificationService.java      # Core gamification engine
│   ├── entity/                           # JPA entities
│   │   ├── RewardRule.java
│   │   ├── UserGamificationProfile.java
│   │   ├── UserRewardLedger.java
│   │   └── UserBadge.java
│   ├── plugin/
│   │   ├── RewardPlugin.java             # Interface for extensibility
│   │   ├── PointsRewardPlugin.java       # Points implementation
│   │   └── BadgeRewardPlugin.java        # Badge implementation
│   ├── repository/                       # Database access
│   ├── config/
│   │   └── CorsConfig.java               # ✨ NEW: Enable cross-origin requests
│   └── GamificationApplication.java
├── src/main/resources/
│   ├── application.properties            # Configuration
│   ├── schema.sql                        # Database initialization
│   └── static/
│       └── dashboard.html                # ✨ NEW: Web UI (1000+ lines)
└── src/test/                            # Unit tests

GAMIFICATION_SETUP_GUIDE.md              # Detailed setup & testing guide
README.md                                 # This file
```

---

## 🚀 Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.0+
- Ports 8080 and 8081 available

### Step 1: Database Setup
```bash
# Start MySQL
mysql -u root -p

# Create database (if needed)
CREATE DATABASE IF NOT EXISTS cib_fund_transfer;
USE cib_fund_transfer;

# Schema will auto-create via Hibernate with ddl-auto=update
```

### Step 2: Build & Run Banking App
```bash
cd cib-fund-transfer
mvn clean install
mvn spring-boot:run

# Runs on: http://localhost:8080
```

### Step 3: Build & Run Gamification Service
```bash
cd ../gamification-service
mvn clean install
mvn spring-boot:run

# Runs on: http://localhost:8081
# Dashboard: http://localhost:8081/dashboard.html
```

### Step 4: Access the Dashboard
```
Open browser: http://localhost:8081/dashboard.html
```

---

## 🎮 Demo Scenarios

### Scenario 1: Earn Points via Referral
1. **Create Maker (Referrer)**
   ```bash
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Alice"}'
   # Response: { "id": 1, "name": "Alice", ... }
   ```

2. **Create Maker (Referred)**
   ```bash
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Bob", "referralId": "1"}'
   # Response: { "id": 2, "name": "Bob", ... }
   # 🎯 GAMIFICATION EVENT: Bob gets 100 points for being referred!
   ```

3. **Verify on Dashboard**
   - Go to http://localhost:8081/dashboard.html
   - Profile tab → Enter User ID: 2
   - Should show: **100 Total Points**

### Scenario 2: Earn Points via Transaction
1. **Create a Transaction**
   - Maker Alice initiates a transfer
   - Status: PENDING_APPROVAL

2. **Approve Transaction**
   - Checker Carol approves it
   - Status: SUCCESS
   - 🎯 GAMIFICATION EVENT: Alice gets 25 points!

3. **Check Progress**
   ```bash
   curl http://localhost:8081/api/gamification/profile/1
   ```
   Response shows updated totalPoints

### Scenario 3: Use Dashboard to Test
1. Open http://localhost:8081/dashboard.html
2. Go to **"🧪 Test Events"** tab
3. Click **"Test Transaction Completed"**
4. Enter User ID (e.g., 1) and Amount (e.g., 5000)
5. Check Profile tab → Points increased!

---

## 📊 Database Schema

### Tables Created Automatically

#### `gamification_rules`
```
id (PK)          | INT
event_name       | VARCHAR(100) - Event trigger name
reward_type      | VARCHAR(50)  - POINTS, BADGE, COUPON
reward_value     | INT          - Points/badges to award
status           | VARCHAR(20)  - ACTIVE or INACTIVE
description      | TEXT         - Rule description
valid_from       | TIMESTAMP    - When rule becomes active
valid_to         | TIMESTAMP    - When rule expires
created_at       | TIMESTAMP    - Creation time
```

#### `user_gamification_profile`
```
user_id          | BIGINT (PK)  - FK to User
total_points     | INT          - Total points earned
current_level    | INT          - User level (1, 2, 3...)
total_badges     | INT          - Badge count
updated_at       | TIMESTAMP    - Last update time
```

#### `user_reward_ledger`
```
id (PK)          | BIGINT
user_id          | BIGINT       - Who earned the reward
event_name       | VARCHAR(100) - Event that triggered it
reward_type      | VARCHAR(50)  - POINTS, BADGE, COUPON
reward_value     | INT          - Actual value awarded
source           | VARCHAR(100) - Source/context
awarded_at       | TIMESTAMP    - When awarded
```

#### `user_badges`
```
id (PK)          | BIGINT
user_id          | BIGINT       - Badge owner
badge_name       | VARCHAR(100) - Badge identifier
badge_value      | INT          - Badge tier/level
earned_at        | TIMESTAMP    - When earned
```

---

## 🔌 Plugin Architecture

### How Plugins Work

1. **Create a Plugin**
   ```java
   @Component
   public class MyRewardPlugin implements RewardPlugin {
       
       @Override
       public String getRewardType() {
           return "MY_REWARD_TYPE";
       }
       
       @Override
       public UserGamificationProfile apply(Long userId, RewardRule rule, 
           Map<String, Object> context, UserGamificationProfile profile) {
           // Your reward logic here
           return profile;
       }
   }
   ```

2. **Auto-Discovery**
   - Spring `@Component` annotation automatically registers it
   - `RewardPluginRegistry` picks it up
   - No configuration needed!

3. **Create a Rule**
   ```sql
   INSERT INTO gamification_rules 
   (event_name, reward_type, reward_value, status, description, valid_from, valid_to)
   VALUES 
   ('MY_EVENT', 'MY_REWARD_TYPE', 50, 'ACTIVE', 'My custom rule', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));
   ```

4. **Trigger It**
   ```bash
   curl -X POST http://localhost:8081/api/gamification/event \
     -H "Content-Type: application/json" \
     -d '{
       "eventName": "MY_EVENT",
       "userId": 123,
       "context": { "extra": "data" }
     }'
   ```

---

## 🌐 API Endpoints

### Gamification Service (`http://localhost:8081`)

#### Get User Profile
```
GET /api/gamification/profile/{userId}

Response:
{
  "userId": 1,
  "totalPoints": 150,
  "currentLevel": 2,
  "totalBadges": 1,
  "updatedAt": "2024-01-15T10:30:00Z"
}
```

#### Get Reward History
```
GET /api/gamification/history/{userId}

Response:
[
  {
    "id": 1,
    "userId": 1,
    "eventName": "USER_REFERRED",
    "rewardType": "POINTS",
    "rewardValue": 100,
    "source": "referral#2",
    "awardedAt": "2024-01-15T10:00:00Z"
  },
  ...
]
```

#### Get Badges
```
GET /api/gamification/badges/{userId}

Response:
[
  {
    "id": 1,
    "userId": 1,
    "badgeName": "Power User",
    "badgeValue": 1,
    "earnedAt": "2024-01-15T10:30:00Z"
  }
]
```

#### Get Active Rules
```
GET /api/gamification/rules

Response:
[
  {
    "id": 1,
    "eventName": "USER_REFERRED",
    "rewardType": "POINTS",
    "rewardValue": 100,
    "status": "ACTIVE",
    "description": "Reward for referring a new user",
    "validFrom": "2024-01-01T00:00:00Z",
    "validTo": "2025-12-31T23:59:59Z"
  },
  ...
]
```

#### Trigger Event
```
POST /api/gamification/event

Body:
{
  "eventName": "TRANSACTION_COMPLETED",
  "userId": 1,
  "context": {
    "amount": 5000,
    "debitAccountId": 1,
    "beneficiaryAccountId": 2
  }
}

Response: HTTP 200 OK
```

---

## 📡 Event Integration with Banking App

### How Events Flow

```
1. User creates account with referral ID
   ↓
2. MakerService calls gamificationEventPublisher.publishUserReferred()
   ↓
3. GamificationEventPublisher sends HTTP POST to gamification service
   ↓
4. GamificationService evaluates rules
   ↓
5. Matching plugins execute, awards are recorded
   ↓
6. User's profile updated with new points/badges
   ↓
7. Dashboard shows real-time progress
```

### Integrated Service Methods

#### MakerService
```java
// When a maker is created with a referral ID:
gamificationEventPublisher.publishUserReferred(
    maker.getId(),           // New user ID
    referrerUserId           // Referrer's user ID
);
```

#### ApprovalService  
```java
// When a transaction is approved and executed:
gamificationEventPublisher.publishTransactionCompleted(
    txn.getCreatedBy(),      // Maker who initiated
    txn.getAmount().longValue(),
    txn.getDebitAccountId(),
    txn.getBeneficiaryAccountId()
);
```

### Configuration
```properties
# In banking app's application.properties
gamification.service.url=http://localhost:8081

# Timeouts: 5s connection, 10s read
```

---

## 🎨 Dashboard Features

### Profile Tab
- View total points earned
- See current level
- Track badge count
- Progress bar to next level

### Rewards & History Tab
- Complete reward ledger
- Event names and timestamps
- Reward types and values
- Filterable by user ID

### Badges Tab
- Gallery of earned badges
- Badge dates and tiers
- All milestone achievements

### Rules Configuration Tab
- View all active reward rules
- Rule validity periods
- Reward values and types
- Status (ACTIVE/INACTIVE)

### Test Events Tab
- Simulate transaction completions
- Simulate user referrals
- Custom event testing
- Perfect for QA and demos

---

## 🔧 Extending the System

### Add a New Reward Type Plugin

1. Create `CouponRewardPlugin.java`:
```java
package com.cib.gamification.plugin;

import org.springframework.stereotype.Component;

@Component
public class CouponRewardPlugin implements RewardPlugin {
    
    @Override
    public String getRewardType() {
        return "COUPON";
    }
    
    @Override
    public UserGamificationProfile apply(Long userId, RewardRule rule,
        Map<String, Object> context, UserGamificationProfile profile) {
        
        // Generate coupon code
        String couponCode = "COUPON_" + userId + "_" + System.currentTimeMillis();
        
        // Save to database (would need UserCoupon entity)
        // couponRepository.save(new UserCoupon(userId, couponCode, rule.getRewardValue()));
        
        return profile;
    }
}
```

2. The plugin auto-registers - no configuration needed!

3. Create rules in database:
```sql
INSERT INTO gamification_rules 
(event_name, reward_type, reward_value, status, description, valid_from, valid_to)
VALUES 
('HIGH_VALUE_TRANSACTION', 'COUPON', 500, 'ACTIVE', '500 rupee coupon for transactions > 10000', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));
```

### Add a New Event Type

1. In `ApprovalService`, add event trigger:
```java
if (milestone condition) {
    gamificationEventPublisher.publishEvent(
        "MY_NEW_EVENT",
        userId,
        Map.of("context", "data")
    );
}
```

2. Create rule in database:
```sql
INSERT INTO gamification_rules 
(event_name, reward_type, reward_value, status)
VALUES 
('MY_NEW_EVENT', 'POINTS', 200, 'ACTIVE');
```

3. Done! The rule auto-evaluates.

---

## 🧪 Testing

### Unit Tests
```bash
# Banking app tests
cd cib-fund-transfer
mvn test

# Gamification service tests
cd ../gamification-service
mvn test
```

### Integration Tests
1. Start both services
2. Use curl commands from GAMIFICATION_SETUP_GUIDE.md
3. Verify rewards appear in profiles and ledgers
4. Check dashboard for real-time updates

### Load Testing
```bash
# Generate high volume of events
for i in {1..100}; do
  curl -X POST http://localhost:8081/api/gamification/event \
    -H "Content-Type: application/json" \
    -d '{"eventName":"TRANSACTION_COMPLETED","userId":'$i',"context":{"amount":1000}}'
done
```

---

## 🛠️ Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| Dashboard shows "Failed to load profile" | Gamification service not running | Ensure service on port 8081 is running |
| Events not awarding rewards | Rules inactive or expired | Check `gamification_rules` table, ensure `status='ACTIVE'` and dates are current |
| CORS errors in browser | CORS not configured | Verify `CorsConfig.java` is loaded and includes your origin |
| Database connection error | MySQL not running or wrong credentials | Check MySQL is running, verify credentials in `application.properties` |
| Banking app won't start | Gamification service not running | Both services must run independently, but banking doesn't need it to start |

---

## 📚 Additional Documentation

- **[GAMIFICATION_SETUP_GUIDE.md](GAMIFICATION_SETUP_GUIDE.md)** - Complete setup, testing scenarios, API reference
- **[API_DOCUMENTATION.md](cib-fund-transfer/API_DOCUMENTATION.md)** - Banking app API docs
- **[cib-fund-transfer/README.md](cib-fund-transfer/README.md)** - Banking app overview

---

## 🎯 Future Enhancements (Phase 2+)

- [ ] Admin panel for rule management (UI instead of database queries)
- [ ] Coupon/Voucher plugin implementation
- [ ] Leaderboards and rankings
- [ ] Email notifications for achievements
- [ ] User level tiers with special perks
- [ ] Reward redemption system
- [ ] Integration with external reward providers
- [ ] Real-time notifications (WebSocket)
- [ ] Analytics dashboard for admins

---

## 📝 Architecture Philosophy

### 1. **Loose Coupling**
- Banking app doesn't depend on gamification code
- Communication via HTTP REST, not Java method calls
- Services can run independently

### 2. **Plugin Extensibility**
- New reward types without modifying core engine
- Data-driven rules instead of hardcoded logic
- Clean interface-based design

### 3. **Graceful Degradation**
- Banking operations continue if gamification service is down
- Try-catch blocks prevent cascading failures
- Retry logic with timeouts

### 4. **Single Source of Truth**
- One database for both systems
- No data duplication
- Consistent user IDs across services

### 5. **Real-Time Feedback**
- Web dashboard for instant progress updates
- Reward ledger for transparency
- Admin tools for rule management

---

## 📞 Support

For issues or questions:
1. Check logs in both service consoles
2. Review GAMIFICATION_SETUP_GUIDE.md
3. Verify database schema with `SELECT * FROM gamification_rules;`
4. Use dashboard test events to verify connectivity

---

## ✨ Summary

You now have a **production-ready, extensible gamification system** integrated with your banking application:

✅ Points for referrals and transactions  
✅ Badges for milestones  
✅ Beautiful dashboard for tracking progress  
✅ Plugin system for adding new reward types  
✅ Data-driven rules for flexibility  
✅ Tight integration with banking app  
✅ Complete documentation  

**Next Step**: Follow the Quick Start above to get both services running and access the dashboard!

Happy Gamifying! 🎮✨
