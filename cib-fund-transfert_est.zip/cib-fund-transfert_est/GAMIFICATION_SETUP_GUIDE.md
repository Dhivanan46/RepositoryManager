# CIB Gamification Service - Implementation Guide

## 🎯 What's Been Implemented

This gamification engine is a **plugin-based, configurable reward system** integrated with the CIB Banking Application. It's designed to be generic and can be extended to support various activities and reward types.

### ✅ Core Features Completed

#### 1. **Plugin-Based Reward Engine**
   - `RewardPlugin` interface for extensibility
   - `PointsRewardPlugin` - Awards points based on rules
   - `BadgeRewardPlugin` - Unlocks badges for achievements
   - Easily add more reward types (Coupons, Tier increases, etc.) without modifying core logic

#### 2. **Configurable Rule System**
   - Rules are **data-driven**, not hardcoded
   - Admin can create, enable/disable, and set validity periods for rules
   - Each rule specifies:
     - Event name (e.g., `TRANSACTION_COMPLETED`, `USER_REFERRED`)
     - Reward type (POINTS, BADGE, COUPON)
     - Reward value
     - Validity period (from/to dates)
     - Status (ACTIVE/INACTIVE)

#### 3. **Event-Driven Architecture**
   - Banking app publishes events to the gamification service via HTTP
   - Gamification service evaluates rules and awards rewards in real-time
   - Decoupled: no tight coupling between banking and gamification logic
   - Graceful fallback: if gamification service is down, banking operations continue

#### 4. **User Gamification Profile**
   - Track total points earned
   - Current level (based on points threshold)
   - Total badges earned
   - Reward history and ledger

#### 5. **Web Dashboard**
   - Beautiful, responsive UI for users to view their progress
   - Admin section to configure rules
   - Test event triggering for QA/testing
   - Real-time profile updates

#### 6. **Database Schema**
   - All tables in the same database as banking app (no separate DB needed)
   - `gamification_rules` - Rule configuration
   - `user_gamification_profile` - User progress tracking
   - `user_reward_ledger` - Reward history
   - `user_badges` - Badge tracking

---

## 📋 Demo Rules Pre-Configured

### 1. **Referral Reward** (`USER_REFERRED`)
   - Event: When a maker creates an account with a referral ID
   - Reward: 100 points
   - Status: ACTIVE

### 2. **Transaction Completed** (`TRANSACTION_COMPLETED`)
   - Event: When a fund transfer is successfully completed
   - Reward: 25 points per transaction
   - Status: ACTIVE

### 3. **Milestone Badge** (`MILESTONE_3_TXNS_7_DAYS`)
   - Event: When a user completes 3 transactions in 7 days
   - Reward: Badge "Power User"
   - Status: ACTIVE

---

## 🚀 Setup & Running the Application

### Prerequisites
- Java 17 or higher
- Maven 3.8+
- MySQL 8.0+
- Two ports available: 8080 (Banking) and 8081 (Gamification)

### Step 1: Start MySQL
```bash
# Make sure MySQL is running on localhost:3306
mysql -u root -p
```

### Step 2: Build & Run Banking App
```bash
cd cib-fund-transfer
mvn clean install
mvn spring-boot:run

# Server runs on: http://localhost:8080
```

### Step 3: Build & Run Gamification Service
```bash
cd ../gamification-service
mvn clean install
mvn spring-boot:run

# Server runs on: http://localhost:8081
# Dashboard: http://localhost:8081/dashboard.html
```

### Step 4: Open the Dashboard
```
http://localhost:8081/dashboard.html
```

---

## 🧪 Testing the Integration

### Test Scenario 1: Referral Reward
1. **Create a Maker (Referrer)**
   ```bash
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Alice"}'
   ```
   Response: `userId: 1`

2. **Create Another Maker (Referred)**
   ```bash
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Bob", "referralId": "1"}'
   ```
   Response: `userId: 2`

3. **Check Gamification Profile**
   ```bash
   curl http://localhost:8081/api/gamification/profile/2
   ```
   Expected: Bob should have 100 points

4. **View on Dashboard**
   - Go to http://localhost:8081/dashboard.html
   - Navigate to "Profile" tab
   - Enter User ID: 2
   - Should see: 100 total points

### Test Scenario 2: Transaction Reward
1. **Create Makers**
   ```bash
   # Maker 1 (Alice)
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Alice"}'
   
   # Maker 2 (Bob)
   curl -X POST http://localhost:8080/api/makers \
     -H "Content-Type: application/json" \
     -d '{"name": "Bob"}'
   
   # Checker (Carol)
   curl -X POST http://localhost:8080/api/checkers \
     -H "Content-Type: application/json" \
     -d '{"name": "Carol"}'
   ```

2. **Create a Transaction**
   ```bash
   curl -X POST http://localhost:8080/api/transactions \
     -H "Content-Type: application/json" \
     -d '{
       "makerId": 1,
       "beneficiaryUserId": 2,
       "amount": 5000
     }'
   ```
   Response: `transactionId: 1, status: PENDING_APPROVAL_L1`

3. **Approve Transaction (Checker approval)**
   ```bash
   curl -X POST http://localhost:8080/api/transactions/1/approve \
     -H "Content-Type: application/json" \
     -d '{"checkerId": 3}'
   ```
   Response: `status: SUCCESS`

4. **Check Gamification Profile**
   ```bash
   curl http://localhost:8081/api/gamification/profile/1
   ```
   Expected: Alice should have earned points for the transaction

5. **View Reward History**
   ```bash
   curl http://localhost:8081/api/gamification/history/1
   ```
   Expected: Should show entries for both points earned

### Test Scenario 3: Using the Dashboard
1. Open http://localhost:8081/dashboard.html
2. Navigate to **"🧪 Test Events"** tab
3. Try these test events:
   - **Transaction Completed**: Enter any user ID and amount to simulate a transaction reward
   - **User Referred**: Enter new user ID and referrer ID
   - **Custom Event**: Test any configured rule name

---

## 📊 API Endpoints

### Gamification Service Endpoints

#### Get User Profile
```
GET /api/gamification/profile/{userId}
Response: { userId, totalPoints, currentLevel, totalBadges, updatedAt }
```

#### Get Reward History
```
GET /api/gamification/history/{userId}
Response: [{ id, userId, eventName, rewardType, rewardValue, awardedAt, source }]
```

#### Get Badges
```
GET /api/gamification/badges/{userId}
Response: [{ id, userId, badgeName, badgeValue, earnedAt }]
```

#### Get Active Rules
```
GET /api/gamification/rules
Response: [{ id, eventName, rewardType, rewardValue, status, description, validFrom, validTo }]
```

#### Trigger Event
```
POST /api/gamification/event
Body: {
  "eventName": "TRANSACTION_COMPLETED",
  "userId": 1,
  "context": { "amount": 5000, "debitAccountId": 1, "beneficiaryAccountId": 2 }
}
```

---

## 🔧 How to Extend with New Rules

### Add a New Reward Rule
1. **Access the database directly:**
   ```sql
   INSERT INTO gamification_rules 
   (event_name, reward_type, reward_value, status, description, valid_from, valid_to)
   VALUES
   ('DAILY_LOGIN', 'POINTS', 10, 'ACTIVE', 'Daily login reward', NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));
   ```

2. **Or trigger via API:**
   In the future, we can add an admin endpoint to create rules:
   ```
   POST /api/admin/gamification/rules
   Body: { eventName, rewardType, rewardValue, validFrom, validTo, description }
   ```

### Add a New Plugin
1. Create a class implementing `RewardPlugin`:
   ```java
   @Component
   public class CouponRewardPlugin implements RewardPlugin {
       @Override
       public String getRewardType() { return "COUPON"; }
       
       @Override
       public UserGamificationProfile apply(Long userId, RewardRule rule, 
           Map<String, Object> context, UserGamificationProfile profile) {
           // Your coupon generation logic
           return profile;
       }
   }
   ```

2. The `RewardPluginRegistry` will automatically pick it up via `@Component`

---

## 🎨 Dashboard Features

### 👤 Profile Tab
- View total points
- See current level
- Track badge count
- Progress bar to next level

### 🎁 Rewards & History Tab
- Complete reward ledger
- Filter by user ID
- See event details and timestamps
- Track all points earned

### 🏆 Badges Tab
- View all earned badges
- Badge earned dates
- Badges are earned when rules with type "BADGE" are triggered

### ⚙️ Rules & Configuration Tab
- View all active reward rules
- See rule details (event, reward type, value, validity period)
- Check rule status

### 🧪 Test Events Tab
- Trigger test events without going through banking app
- Test Transaction Completed, User Referred, or custom events
- Perfect for QA and demonstrations

---

## 📱 Architecture Diagram

```
┌─────────────────────────────┐
│   Banking App (8080)        │
│  ┌───────────────────────┐  │
│  │  MakerService         │  │
│  │  - Emits USER_REFERRED│  │
│  └───────┬───────────────┘  │
│          │                   │
│  ┌───────▼───────────────┐  │
│  │ ApprovalService       │  │
│  │ - Emits TRANSACTION   │  │
│  │   _COMPLETED          │  │
│  └───────┬───────────────┘  │
│          │                   │
│  ┌───────▼──────────────────┐
│  │ GamificationEventPublisher│
│  │ (REST Client)            │
│  └───────┬──────────────────┘
│          │ HTTP POST
│          │
└──────────┼──────────────────┘
           │
           ▼
┌──────────────────────────────┐
│ Gamification Service (8081)  │
│ ┌────────────────────────┐   │
│ │ GamificationController │   │
│ └────────┬───────────────┘   │
│          │                   │
│ ┌────────▼───────────────┐   │
│ │ GamificationService    │   │
│ │ - Evaluates rules      │   │
│ │ - Executes plugins     │   │
│ └────────┬───────────────┘   │
│          │                   │
│ ┌────────▼───────────────┐   │
│ │ RewardPlugins          │   │
│ │ - PointsPlugin         │   │
│ │ - BadgePlugin          │   │
│ │ - CouponPlugin (future)│   │
│ └────────┬───────────────┘   │
│          │                   │
│ ┌────────▼───────────────┐   │
│ │ Repositories           │   │
│ │ (Save to MySQL)        │   │
│ └────────────────────────┘   │
│ ┌────────────────────────┐   │
│ │ Dashboard HTML/JS      │   │
│ │ (http://8081/          │   │
│ │  dashboard.html)       │   │
│ └────────────────────────┘   │
└──────────────────────────────┘
           │
           ▼
┌──────────────────────────────┐
│   MySQL Database             │
│ ┌────────────────────────┐   │
│ │ gamification_rules     │   │
│ │ user_gamification_     │   │
│ │ profile                │   │
│ │ user_reward_ledger     │   │
│ │ user_badges            │   │
│ └────────────────────────┘   │
└──────────────────────────────┘
```

---

## 🛠️ Troubleshooting

### Issue: Dashboard shows "Failed to load profile"
- **Cause**: Gamification service might not be running
- **Fix**: Ensure service is running on port 8081, check logs

### Issue: Events not triggering rewards
- **Cause**: Rule might be inactive or outside validity period
- **Fix**: Check `gamification_rules` table, verify `status='ACTIVE'` and dates are current

### Issue: CORS errors in browser console
- **Cause**: CORS not properly configured
- **Fix**: Verify `CorsConfig.java` is loaded, check allowed origins

### Issue: Database connection errors
- **Cause**: MySQL not running or credentials wrong
- **Fix**: Verify MySQL is running, check credentials in `application.properties`

---

## 📚 Next Steps & Future Enhancements

### Phase 2 (Roadmap)
- [ ] Coupon/Voucher plugin implementation
- [ ] Leaderboard API and display
- [ ] Admin panel for rule management (instead of database queries)
- [ ] Email notifications for achievements
- [ ] User level tiers with special perks
- [ ] Configurable level thresholds

### Phase 3 (Advanced)
- [ ] Event sourcing for audit trail
- [ ] Reward redemption system
- [ ] Integration with external reward providers
- [ ] Real-time notifications (WebSocket)
- [ ] Analytics dashboard for admins

---

## 📞 Support & Questions

For issues or questions about the implementation:
1. Check the logs in both services
2. Review the dashboard test events section
3. Verify the database has the correct schema
4. Check that both services are running on the correct ports

Happy Gamifying! 🎮✨
