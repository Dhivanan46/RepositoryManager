package com.cib.gamification.service;

import com.cib.gamification.entity.AdminAccount;
import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserGamificationProfile;
import com.cib.gamification.plugin.RewardPlugin;
import com.cib.gamification.repository.AdminAccountRepository;
import com.cib.gamification.repository.RewardRuleRepository;
import com.cib.gamification.repository.UserBadgeRepository;
import com.cib.gamification.repository.UserGamificationProfileRepository;
import com.cib.gamification.repository.UserRewardLedgerRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GamificationServiceAdminTest {

    @Mock
    private RewardRuleRepository rewardRuleRepository;

    @Mock
    private UserGamificationProfileRepository profileRepository;

    @Mock
    private UserRewardLedgerRepository ledgerRepository;

    @Mock
    private UserBadgeRepository badgeRepository;

    @Mock
    private AdminAccountRepository adminAccountRepository;

    @Mock
    private RewardPlugin pointsPlugin;

    @InjectMocks
    private GamificationService gamificationService;

    @Test
    void adminLoginShouldAcceptConfiguredCredentials() {
        AdminAccount admin = new AdminAccount();
        admin.setUsername("admin");
        admin.setPassword("admin123");
        admin.setApplicationId("bank");
        admin.setActive(true);
        when(adminAccountRepository.findByUsernameAndApplicationId("admin", "bank")).thenReturn(Optional.of(admin));

        assertTrue(gamificationService.adminLogin("admin", "admin123", "bank"));
        assertFalse(gamificationService.adminLogin("admin", "wrong-pass", "bank"));
    }

    @Test
    void appSpecificRulesShouldRemainIsolated() {
        when(adminAccountRepository.existsByUsernameAndApplicationId("zomato-admin", "zomato")).thenReturn(false);
        when(adminAccountRepository.save(any(AdminAccount.class))).thenAnswer(invocation -> invocation.getArgument(0));

        AdminAccount admin = gamificationService.registerAdmin("Zomato Admin", "zomato-admin", "secret123", "zomato");
        assertNotNull(admin);
        assertEquals("zomato", admin.getApplicationId());

        RewardRule bankRule = new RewardRule();
        bankRule.setEventName("BANK_TRANSFER");
        bankRule.setApplicationId("bank");
        bankRule.setRewardType("POINTS");
        bankRule.setRewardValue(new BigDecimal("10.00"));
        bankRule.setStatus("ACTIVE");

        RewardRule zomatoRule = new RewardRule();
        zomatoRule.setEventName("ZOMATO_ORDER");
        zomatoRule.setApplicationId("zomato");
        zomatoRule.setRewardType("POINTS");
        zomatoRule.setRewardValue(new BigDecimal("50.00"));
        zomatoRule.setStatus("ACTIVE");

        when(rewardRuleRepository.findByApplicationIdAndStatus("bank", "ACTIVE")).thenReturn(java.util.List.of(bankRule));
        when(rewardRuleRepository.findByApplicationIdAndStatus("zomato", "ACTIVE")).thenReturn(java.util.List.of(zomatoRule));

        assertEquals(1, gamificationService.getRules("bank").size());
        assertEquals(1, gamificationService.getRules("zomato").size());
        assertEquals("BANK_TRANSFER", gamificationService.getRules("bank").get(0).getEventName());
        assertEquals("ZOMATO_ORDER", gamificationService.getRules("zomato").get(0).getEventName());
    }

    @Test
    void createRuleShouldPersistDynamicEventConfig() {
        RewardRule rule = new RewardRule();
        rule.setEventName("NEW_APP_EVENT");
        rule.setRewardType("POINTS");
        rule.setRewardValue(new BigDecimal("50.00"));
        rule.setStatus("ACTIVE");
        rule.setDescription("Custom event");
        rule.setConfigJson("{\"bonusMultiplier\":2}");
        rule.setValidFrom(LocalDateTime.now().minusDays(1));
        rule.setValidTo(LocalDateTime.now().plusDays(30));

        when(rewardRuleRepository.save(any(RewardRule.class))).thenReturn(rule);

        RewardRule created = gamificationService.createRule(
                "NEW_APP_EVENT",
                "POINTS",
                new BigDecimal("50.00"),
                "ACTIVE",
                "Custom event",
                "{\"bonusMultiplier\":2}",
                LocalDateTime.now().minusDays(1),
                LocalDateTime.now().plusDays(30));

        assertNotNull(created);
        assertEquals("NEW_APP_EVENT", created.getEventName());
        assertEquals("POINTS", created.getRewardType());
        assertEquals("ACTIVE", created.getStatus());
    }

    @Test
    void getProfileShouldWorkWithoutAuthentication() {
        UserGamificationProfile profile = new UserGamificationProfile();
        profile.setApplicationId("bank");
        profile.setUserId(99L);
        profile.setTotalPoints(new BigDecimal("150.00"));
        profile.setCurrentLevel(2);
        profile.setTotalBadges(3);

        when(profileRepository.findByApplicationIdAndUserId("bank", 99L)).thenReturn(Optional.of(profile));

        UserGamificationProfile loaded = gamificationService.getProfile(99L);
        assertNotNull(loaded);
        assertEquals(99L, loaded.getUserId());
        assertEquals(new BigDecimal("150.00"), loaded.getTotalPoints());
    }

    @Test
    void pointConversionRateShouldDefaultTo100AndAllowUpdate() {
        when(profileRepository.findByApplicationIdAndUserId("bank", 15L)).thenReturn(Optional.of(new UserGamificationProfile()));

        BigDecimal defaultRate = gamificationService.getPointsPerRupee("bank");
        assertEquals(new BigDecimal("100.00"), defaultRate);

        var updated = gamificationService.updatePointsPerRupee("bank", new BigDecimal("50.00"));
        assertEquals(new BigDecimal("50.00"), updated.getPointsPerRupee());
        assertEquals(new BigDecimal("50.00"), gamificationService.getPointsPerRupee("bank"));
    }
}
