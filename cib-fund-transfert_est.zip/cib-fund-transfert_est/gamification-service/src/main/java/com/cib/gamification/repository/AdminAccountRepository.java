package com.cib.gamification.repository;

import com.cib.gamification.entity.AdminAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AdminAccountRepository extends JpaRepository<AdminAccount, Long> {
    Optional<AdminAccount> findByUsernameAndApplicationId(String username, String applicationId);
    Optional<AdminAccount> findByUsername(String username);
    boolean existsByUsernameAndApplicationId(String username, String applicationId);
    boolean existsByUsername(String username);
}
