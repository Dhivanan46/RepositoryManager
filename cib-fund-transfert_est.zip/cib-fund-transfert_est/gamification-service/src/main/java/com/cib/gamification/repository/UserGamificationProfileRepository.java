package com.cib.gamification.repository;

import com.cib.gamification.entity.UserGamificationProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserGamificationProfileRepository extends JpaRepository<UserGamificationProfile, Long> {
    java.util.Optional<UserGamificationProfile> findByApplicationIdAndUserId(String applicationId, Long userId);
}
