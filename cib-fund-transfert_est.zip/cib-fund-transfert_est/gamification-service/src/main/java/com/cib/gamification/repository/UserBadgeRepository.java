package com.cib.gamification.repository;

import com.cib.gamification.entity.UserBadge;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserBadgeRepository extends JpaRepository<UserBadge, Long> {
    List<UserBadge> findByApplicationIdAndUserIdOrderByEarnedAtDesc(String applicationId, Long userId);
    List<UserBadge> findByUserIdOrderByEarnedAtDesc(Long userId);
}
