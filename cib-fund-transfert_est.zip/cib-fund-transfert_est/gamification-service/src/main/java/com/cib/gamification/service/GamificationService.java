package com.cib.gamification.service;

import com.cib.gamification.entity.AdminAccount;
import com.cib.gamification.entity.ApplicationSetting;
import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserBadge;
import com.cib.gamification.entity.UserGamificationProfile;
import com.cib.gamification.entity.UserRewardLedger;
import com.cib.gamification.plugin.RewardPlugin;
import com.cib.gamification.repository.AdminAccountRepository;
import com.cib.gamification.repository.ApplicationSettingRepository;
import com.cib.gamification.repository.RewardRuleRepository;
import com.cib.gamification.repository.UserBadgeRepository;
import com.cib.gamification.repository.UserGamificationProfileRepository;
import com.cib.gamification.repository.UserRewardLedgerRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class GamificationService {

    private static final String DEFAULT_ADMIN_USERNAME = "admin";
    private static final String DEFAULT_ADMIN_PASSWORD = "admin123";
    private static final String POINTS_PER_RUPEE_KEY = "points_per_rupee";
    private static final BigDecimal DEFAULT_POINTS_PER_RUPEE = new BigDecimal("100.00");

    private final RewardRuleRepository rewardRuleRepository;
    private final UserGamificationProfileRepository profileRepository;
    private final UserRewardLedgerRepository ledgerRepository;
    private final UserBadgeRepository badgeRepository;
    private final AdminAccountRepository adminAccountRepository;
    private final ApplicationSettingRepository applicationSettingRepository;
    private final List<RewardPlugin> rewardPlugins;

    @PostConstruct
    public void seedDefaults() {
        if (rewardRuleRepository.count() == 0) {
            RewardRule referral = new RewardRule();
            referral.setEventName("USER_REFERRED");
            referral.setRewardType("POINTS");
            referral.setRewardValue(new BigDecimal("100.00"));
            referral.setStatus("ACTIVE");
            referral.setDescription("Referral reward");
            referral.setValidFrom(LocalDateTime.now().minusDays(30));
            referral.setValidTo(LocalDateTime.now().plusDays(365));
            rewardRuleRepository.save(referral);

            RewardRule transfer = new RewardRule();
            transfer.setEventName("TRANSACTION_COMPLETED");
            transfer.setRewardType("POINTS");
            transfer.setRewardValue(new BigDecimal("25.00"));
            transfer.setStatus("ACTIVE");
            transfer.setDescription("Transaction reward");
            transfer.setValidFrom(LocalDateTime.now().minusDays(30));
            transfer.setValidTo(LocalDateTime.now().plusDays(365));
            rewardRuleRepository.save(transfer);

            RewardRule milestone = new RewardRule();
            milestone.setEventName("MILESTONE_3_TXNS_7_DAYS");
            milestone.setRewardType("BADGE");
            milestone.setRewardValue(new BigDecimal("1.00"));
            milestone.setStatus("ACTIVE");
            milestone.setDescription("Three transactions in seven days");
            milestone.setValidFrom(LocalDateTime.now().minusDays(30));
            milestone.setValidTo(LocalDateTime.now().plusDays(365));
            rewardRuleRepository.save(milestone);
        }

        if (!adminAccountRepository.existsByUsernameAndApplicationId(DEFAULT_ADMIN_USERNAME, "bank")) {
            AdminAccount admin = new AdminAccount();
            admin.setUsername(DEFAULT_ADMIN_USERNAME);
            admin.setPassword(DEFAULT_ADMIN_PASSWORD);
            admin.setName("System Administrator");
            admin.setApplicationId("bank");
            admin.setActive(true);
            adminAccountRepository.save(admin);
        }

        ensureDefaultPointsPerRupee("bank");
    }

    public boolean adminLogin(String username, String password) {
        return adminLogin(username, password, "bank");
    }

    public boolean adminLogin(String username, String password, String applicationId) {
        if (username == null || password == null) {
            return false;
        }

        String normalizedApp = normalizeApplicationId(applicationId);
        String normalizedUsername = username.trim();
        if (DEFAULT_ADMIN_USERNAME.equalsIgnoreCase(normalizedUsername)
                && DEFAULT_ADMIN_PASSWORD.equals(password)
                && (normalizedApp == null || "bank".equals(normalizedApp))) {
            return true;
        }

        return adminAccountRepository.findByUsernameAndApplicationId(normalizedUsername, normalizedApp)
                .filter(AdminAccount::isActive)
                .map(account -> account.getPassword().equals(password))
                .orElse(false);
    }

    @Transactional
    public AdminAccount registerAdmin(String name, String username, String password) {
        return registerAdmin(name, username, password, "bank");
    }

    @Transactional
    public AdminAccount registerAdmin(String name, String username, String password, String applicationId) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Admin name is required");
        }
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("Username is required");
        }
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        String normalizedApp = normalizeApplicationId(applicationId);
        if (adminAccountRepository.existsByUsernameAndApplicationId(username.trim(), normalizedApp)) {
            throw new IllegalArgumentException("Username already exists for this application");
        }

        AdminAccount admin = new AdminAccount();
        admin.setName(name.trim());
        admin.setUsername(username.trim());
        admin.setPassword(password);
        admin.setApplicationId(normalizedApp);
        admin.setActive(true);
        return adminAccountRepository.save(admin);
    }

    @Transactional
    public RewardRule createRule(String eventName, String rewardType, BigDecimal rewardValue,
                                String status, String description, String configJson,
                                LocalDateTime validFrom, LocalDateTime validTo) {
        return createRule(eventName, rewardType, rewardValue, status, description, configJson, validFrom, validTo, "bank");
    }

    @Transactional
    public RewardRule createRule(String eventName, String rewardType, BigDecimal rewardValue,
                                String status, String description, String configJson,
                                LocalDateTime validFrom, LocalDateTime validTo, String applicationId) {
        if (eventName == null || eventName.isBlank()) {
            throw new IllegalArgumentException("eventName is required");
        }
        if (rewardType == null || rewardType.isBlank()) {
            throw new IllegalArgumentException("rewardType is required");
        }
        validateRewardType(rewardType);

        RewardRule rule = new RewardRule();
        rule.setEventName(eventName.trim());
        rule.setRewardType(rewardType.trim().toUpperCase());
        rule.setRewardValue(rewardValue == null ? BigDecimal.ZERO : rewardValue);
        rule.setStatus(status == null || status.isBlank() ? "ACTIVE" : status.trim().toUpperCase());
        rule.setApplicationId(normalizeApplicationId(applicationId));
        rule.setDescription(description);
        rule.setConfigJson(configJson);
        rule.setValidFrom(validFrom);
        rule.setValidTo(validTo);
        return rewardRuleRepository.save(rule);
    }

    @Transactional
    public RewardRule updateRule(Long ruleId, String eventName, String rewardType, BigDecimal rewardValue,
                                String status, String description, String configJson,
                                LocalDateTime validFrom, LocalDateTime validTo) {
        RewardRule rule = rewardRuleRepository.findById(ruleId)
                .orElseThrow(() -> new IllegalArgumentException("Reward rule not found: " + ruleId));

        if (eventName != null && !eventName.isBlank()) {
            rule.setEventName(eventName.trim());
        }
        if (rewardType != null && !rewardType.isBlank()) {
            validateRewardType(rewardType);
            rule.setRewardType(rewardType.trim().toUpperCase());
        }
        if (rewardValue != null) {
            rule.setRewardValue(rewardValue);
        }
        if (status != null && !status.isBlank()) {
            rule.setStatus(status.trim().toUpperCase());
        }
        if (description != null) {
            rule.setDescription(description);
        }
        if (configJson != null) {
            rule.setConfigJson(configJson);
        }
        if (validFrom != null) {
            rule.setValidFrom(validFrom);
        }
        if (validTo != null) {
            rule.setValidTo(validTo);
        }
        return rewardRuleRepository.save(rule);
    }

    @Transactional
    public boolean deleteRule(Long ruleId) {
        if (!rewardRuleRepository.existsById(ruleId)) {
            return false;
        }
        rewardRuleRepository.deleteById(ruleId);
        return true;
    }

    public List<RewardRule> getAllRules() {
        return rewardRuleRepository.findAll();
    }

    public List<RewardRule> getAllRules(String applicationId) {
        return rewardRuleRepository.findByApplicationId(normalizeApplicationId(applicationId));
    }

    @Transactional
    public void processEvent(String eventName, Long userId, Map<String, Object> context) {
        processEvent(eventName, userId, context, "bank");
    }

    @Transactional
    public void processEvent(String eventName, Long userId, Map<String, Object> context, String applicationId) {
        if (userId == null || eventName == null || eventName.isBlank()) {
            throw new IllegalArgumentException("userId and eventName are required");
        }

        String normalizedApp = normalizeApplicationId(applicationId);
        List<RewardRule> rules = rewardRuleRepository.findByApplicationIdAndEventNameAndStatus(normalizedApp, eventName, "ACTIVE");
        if (rules.isEmpty()) {
            return;
        }

        UserGamificationProfile profile = profileRepository.findByApplicationIdAndUserId(normalizedApp, userId)
                .orElseGet(() -> {
                    UserGamificationProfile p = new UserGamificationProfile();
                    p.setApplicationId(normalizedApp);
                    p.setUserId(userId);
                    p.setTotalPoints(BigDecimal.ZERO);
                    p.setCurrentLevel(1);
                    p.setTotalBadges(0);
                    return p;
                });

        for (RewardRule rule : rules) {
            if (!isRuleActive(rule)) {
                continue;
            }

            RewardPlugin plugin = resolveRewardPlugins().stream()
                    .filter(p -> p.getRewardType().equalsIgnoreCase(rule.getRewardType()))
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("No plugin registered for reward type: " + rule.getRewardType()));

            UserGamificationProfile updated = plugin.apply(userId, rule, context, profile);
            profileRepository.save(updated);

            UserRewardLedger ledger = new UserRewardLedger();
            ledger.setUserId(userId);
            ledger.setApplicationId(normalizedApp);
            ledger.setEventName(eventName);
            ledger.setRewardType(rule.getRewardType());
            ledger.setRewardValue(plugin.calculateRewardValue(rule, context));
            ledger.setSource("event:" + eventName);
            ledgerRepository.save(ledger);

            if ("BADGE".equalsIgnoreCase(rule.getRewardType())) {
                UserBadge badge = new UserBadge();
                badge.setUserId(userId);
                badge.setApplicationId(normalizedApp);
                badge.setBadgeName(eventName);
                badge.setBadgeValue(rule.getDescription());
                badgeRepository.save(badge);
            }

            profile = updated;
        }
    }

    public UserGamificationProfile getProfile(Long userId) {
        return getProfile(userId, "bank");
    }

    public UserGamificationProfile getProfile(Long userId, String applicationId) {
        String normalizedApp = normalizeApplicationId(applicationId);
        return profileRepository.findByApplicationIdAndUserId(normalizedApp, userId).orElseGet(() -> {
            UserGamificationProfile profile = new UserGamificationProfile();
            profile.setApplicationId(normalizedApp);
            profile.setUserId(userId);
            profile.setTotalPoints(BigDecimal.ZERO);
            profile.setCurrentLevel(1);
            profile.setTotalBadges(0);
            return profile;
        });
    }

    public List<RewardRule> getRules() {
        return getRules("bank");
    }

    public List<RewardRule> getRules(String applicationId) {
        return rewardRuleRepository.findByApplicationIdAndStatus(normalizeApplicationId(applicationId), "ACTIVE");
    }

    public List<UserRewardLedger> getHistory(Long userId) {
        return getHistory(userId, "bank");
    }

    public List<UserRewardLedger> getHistory(Long userId, String applicationId) {
        return ledgerRepository.findByApplicationIdAndUserIdOrderByAwardedAtDesc(normalizeApplicationId(applicationId), userId);
    }

    public List<UserBadge> getBadges(Long userId) {
        return getBadges(userId, "bank");
    }

    public List<UserBadge> getBadges(Long userId, String applicationId) {
        return badgeRepository.findByApplicationIdAndUserIdOrderByEarnedAtDesc(normalizeApplicationId(applicationId), userId);
    }

    public BigDecimal getPointsPerRupee(String applicationId) {
        return getOrCreatePointsPerRupeeSetting(normalizeApplicationId(applicationId)).getSettingValue();
    }

    @Transactional
    public ApplicationSetting updatePointsPerRupee(String applicationId, BigDecimal pointsPerRupee) {
        if (pointsPerRupee == null || pointsPerRupee.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("pointsPerRupee must be greater than zero");
        }

        ApplicationSetting setting = getOrCreatePointsPerRupeeSetting(normalizeApplicationId(applicationId));
        setting.setSettingValue(pointsPerRupee);
        return applicationSettingRepository.save(setting);
    }

    @Transactional
    public Map<String, Object> redeemPoints(Long userId, BigDecimal pointsToRedeem, String applicationId) {
        if (userId == null) {
            throw new IllegalArgumentException("userId is required");
        }
        if (pointsToRedeem == null || pointsToRedeem.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("pointsToRedeem must be greater than zero");
        }

        String normalizedApp = normalizeApplicationId(applicationId);
        UserGamificationProfile profile = profileRepository.findByApplicationIdAndUserId(normalizedApp, userId)
                .orElseGet(() -> {
                    UserGamificationProfile p = new UserGamificationProfile();
                    p.setApplicationId(normalizedApp);
                    p.setUserId(userId);
                    p.setTotalPoints(BigDecimal.ZERO);
                    p.setCurrentLevel(1);
                    p.setTotalBadges(0);
                    return p;
                });

        if (profile.getTotalPoints().compareTo(pointsToRedeem) < 0) {
            throw new IllegalArgumentException("Insufficient points balance to redeem");
        }

        BigDecimal pointsPerRupee = getPointsPerRupee(normalizedApp);
        BigDecimal amount = pointsToRedeem.divide(pointsPerRupee, 4, java.math.RoundingMode.HALF_UP);
        profile.setTotalPoints(profile.getTotalPoints().subtract(pointsToRedeem));
        profileRepository.save(profile);

        UserRewardLedger ledger = new UserRewardLedger();
        ledger.setUserId(userId);
        ledger.setApplicationId(normalizedApp);
        ledger.setEventName("POINTS_REDEEMED");
        ledger.setRewardType("POINTS");
        ledger.setRewardValue(pointsToRedeem.negate());
        ledger.setSource("redeem:points");
        ledgerRepository.save(ledger);

        return Map.of(
                "userId", userId,
                "pointsRedeemed", pointsToRedeem,
                "amount", amount,
                "remainingPoints", profile.getTotalPoints(),
                "pointsPerRupee", pointsPerRupee
        );
    }

    private ApplicationSetting getOrCreatePointsPerRupeeSetting(String applicationId) {
        return applicationSettingRepository.findByApplicationIdAndSettingKey(applicationId, POINTS_PER_RUPEE_KEY)
                .orElseGet(() -> {
                    ApplicationSetting setting = new ApplicationSetting();
                    setting.setApplicationId(applicationId);
                    setting.setSettingKey(POINTS_PER_RUPEE_KEY);
                    setting.setSettingValue(DEFAULT_POINTS_PER_RUPEE);
                    return applicationSettingRepository.save(setting);
                });
    }

    private void ensureDefaultPointsPerRupee(String applicationId) {
        applicationSettingRepository.findByApplicationIdAndSettingKey(applicationId, POINTS_PER_RUPEE_KEY)
                .orElseGet(() -> {
                    ApplicationSetting setting = new ApplicationSetting();
                    setting.setApplicationId(applicationId);
                    setting.setSettingKey(POINTS_PER_RUPEE_KEY);
                    setting.setSettingValue(DEFAULT_POINTS_PER_RUPEE);
                    return applicationSettingRepository.save(setting);
                });
    }

    private void validateRewardType(String rewardType) {
        if (rewardType == null || rewardType.isBlank()) {
            throw new IllegalArgumentException("rewardType is required");
        }

        String normalizedType = rewardType.trim().toUpperCase();
        boolean supported = isBuiltInRewardType(normalizedType) || resolveRewardPlugins().stream()
                .anyMatch(plugin -> plugin.getRewardType().equalsIgnoreCase(normalizedType));
        if (!supported) {
            throw new IllegalArgumentException("Unsupported reward type: " + rewardType);
        }
    }

    private boolean isBuiltInRewardType(String rewardType) {
        return "POINTS".equalsIgnoreCase(rewardType) || "BADGE".equalsIgnoreCase(rewardType);
    }

    private String normalizeApplicationId(String applicationId) {
        String normalized = applicationId == null ? "bank" : applicationId.trim().toLowerCase();
        return normalized.isBlank() ? "bank" : normalized;
    }

    private List<RewardPlugin> resolveRewardPlugins() {
        return rewardPlugins == null ? List.of() : rewardPlugins;
    }

    private boolean isRuleActive(RewardRule rule) {
        LocalDateTime now = LocalDateTime.now();
        if (rule.getValidFrom() != null && rule.getValidFrom().isAfter(now)) {
            return false;
        }
        if (rule.getValidTo() != null && rule.getValidTo().isBefore(now)) {
            return false;
        }
        return "ACTIVE".equalsIgnoreCase(rule.getStatus());
    }
}
