package com.cib.gamification.repository;

import com.cib.gamification.entity.ApplicationSetting;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ApplicationSettingRepository extends JpaRepository<ApplicationSetting, Long> {
    Optional<ApplicationSetting> findByApplicationIdAndSettingKey(String applicationId, String settingKey);
}
