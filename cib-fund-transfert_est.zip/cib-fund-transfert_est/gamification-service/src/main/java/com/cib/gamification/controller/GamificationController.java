package com.cib.gamification.controller;

import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserBadge;
import com.cib.gamification.entity.UserGamificationProfile;
import com.cib.gamification.entity.UserRewardLedger;
import com.cib.gamification.service.GamificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/gamification")
@RequiredArgsConstructor
public class GamificationController {

    private final GamificationService gamificationService;

    @PostMapping("/event")
    public ResponseEntity<Void> triggerEvent(@RequestBody Map<String, Object> payload) {
        String eventName = (String) payload.get("eventName");
        Long userId = payload.get("userId") != null ? Long.valueOf(payload.get("userId").toString()) : null;
        String applicationId = payload.get("applicationId") != null ? payload.get("applicationId").toString() : "bank";
        @SuppressWarnings("unchecked")
        Map<String, Object> context = (Map<String, Object>) payload.getOrDefault("context", Map.of());
        gamificationService.processEvent(eventName, userId, context, applicationId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/admin/register")
    public ResponseEntity<Map<String, Object>> registerAdmin(@RequestBody Map<String, String> payload) {
        String name = payload.get("name");
        String username = payload.get("username");
        String password = payload.get("password");
        String applicationId = payload.getOrDefault("applicationId", "bank");
        var admin = gamificationService.registerAdmin(name, username, password, applicationId);
        return ResponseEntity.ok(Map.of(
                "id", admin.getId(),
                "name", admin.getName(),
                "username", admin.getUsername(),
                "applicationId", admin.getApplicationId(),
                "valid", true
        ));
    }

    @PostMapping("/admin/login")
    public ResponseEntity<Map<String, Object>> adminLogin(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");
        String applicationId = payload.getOrDefault("applicationId", "bank");
        boolean valid = gamificationService.adminLogin(username, password, applicationId);
        return ResponseEntity.ok(Map.of("valid", valid, "username", username == null ? "" : username, "applicationId", applicationId));
    }

    @GetMapping("/admin/rules")
    public ResponseEntity<List<RewardRule>> getAllRulesForAdmin(@RequestParam(required = false, defaultValue = "bank") String applicationId) {
        return ResponseEntity.ok(gamificationService.getAllRules(applicationId));
    }

    @PostMapping("/admin/rules")
    public ResponseEntity<RewardRule> createRule(@RequestBody Map<String, Object> payload) {
        String applicationId = payload.get("applicationId") != null ? payload.get("applicationId").toString() : "bank";
        RewardRule created = gamificationService.createRule(
                (String) payload.get("eventName"),
                (String) payload.get("rewardType"),
                payload.get("rewardValue") != null ? new BigDecimal(payload.get("rewardValue").toString()) : BigDecimal.ZERO,
                (String) payload.getOrDefault("status", "ACTIVE"),
                (String) payload.get("description"),
                payload.get("configJson") != null ? payload.get("configJson").toString() : null,
                parseDateTime(payload.get("validFrom")),
                parseDateTime(payload.get("validTo")),
                applicationId
        );
        return ResponseEntity.ok(created);
    }

    @PutMapping("/admin/rules/{id}")
    public ResponseEntity<RewardRule> updateRule(@PathVariable Long id, @RequestBody Map<String, Object> payload) {
        RewardRule updated = gamificationService.updateRule(
                id,
                (String) payload.get("eventName"),
                (String) payload.get("rewardType"),
                payload.get("rewardValue") != null ? new BigDecimal(payload.get("rewardValue").toString()) : null,
                (String) payload.get("status"),
                (String) payload.get("description"),
                payload.get("configJson") != null ? payload.get("configJson").toString() : null,
                parseDateTime(payload.get("validFrom")),
                parseDateTime(payload.get("validTo"))
        );
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/admin/rules/{id}")
    public ResponseEntity<Map<String, Object>> deleteRule(@PathVariable Long id) {
        boolean deleted = gamificationService.deleteRule(id);
        return ResponseEntity.ok(Map.of("deleted", deleted));
    }

    @GetMapping("/profile/{userId}/{applicationId}")
    public ResponseEntity<UserGamificationProfile> getProfile(@PathVariable Long userId, @PathVariable String applicationId) {
        String normalizedApp = applicationId == null || applicationId.isBlank() ? "bank" : applicationId;
        return ResponseEntity.ok(gamificationService.getProfile(userId, normalizedApp));
    }

    @GetMapping("/points-rate/{applicationId}")
    public ResponseEntity<Map<String, Object>> getPointsRate(@PathVariable String applicationId) {
        String normalizedApp = applicationId == null || applicationId.isBlank() ? "bank" : applicationId;
        BigDecimal pointsPerRupee = gamificationService.getPointsPerRupee(normalizedApp);
        return ResponseEntity.ok(Map.of(
                "applicationId", normalizedApp,
                "pointsPerRupee", pointsPerRupee,
                "description", "100 points = 1 rupee"
        ));
    }

    @PutMapping("/points-rate/{applicationId}")
    public ResponseEntity<Map<String, Object>> updatePointsRate(@PathVariable String applicationId, @RequestBody Map<String, Object> payload) {
        String normalizedApp = applicationId == null || applicationId.isBlank() ? "bank" : applicationId;
        BigDecimal pointsPerRupee = payload.get("pointsPerRupee") != null ? new BigDecimal(payload.get("pointsPerRupee").toString()) : null;
        var setting = gamificationService.updatePointsPerRupee(normalizedApp, pointsPerRupee);
        return ResponseEntity.ok(Map.of(
                "applicationId", normalizedApp,
                "pointsPerRupee", setting.getSettingValue(),
                "description", "100 points = 1 rupee"
        ));
    }

    @PostMapping("/redeem")
    public ResponseEntity<Map<String, Object>> redeemPoints(@RequestBody Map<String, Object> payload) {
        Long userId = payload.get("userId") != null ? Long.valueOf(payload.get("userId").toString()) : null;
        BigDecimal pointsToRedeem = payload.get("pointsToRedeem") != null ? new BigDecimal(payload.get("pointsToRedeem").toString()) : null;
        String applicationId = payload.get("applicationId") != null ? payload.get("applicationId").toString() : "bank";
        return ResponseEntity.ok(gamificationService.redeemPoints(userId, pointsToRedeem, applicationId));
    }

    @GetMapping("/rules")
    public ResponseEntity<List<RewardRule>> getRules(@RequestParam(required = false, defaultValue = "bank") String applicationId) {
        return ResponseEntity.ok(gamificationService.getRules(applicationId));
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<UserRewardLedger>> getHistory(@PathVariable Long userId, @RequestParam(required = false, defaultValue = "bank") String applicationId) {
        return ResponseEntity.ok(gamificationService.getHistory(userId, applicationId));
    }

    @GetMapping("/badges/{userId}")
    public ResponseEntity<List<UserBadge>> getBadges(@PathVariable Long userId, @RequestParam(required = false, defaultValue = "bank") String applicationId) {
        return ResponseEntity.ok(gamificationService.getBadges(userId, applicationId));
    }

    private LocalDateTime parseDateTime(Object value) {
        if (value == null || value.toString().isBlank()) {
            return null;
        }
        String raw = value.toString();
        return LocalDateTime.parse(raw);
    }
}
