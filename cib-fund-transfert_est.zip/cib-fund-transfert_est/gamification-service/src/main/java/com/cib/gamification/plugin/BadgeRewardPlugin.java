package com.cib.gamification.plugin;

import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserGamificationProfile;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class BadgeRewardPlugin implements RewardPlugin {

    @Override
    public String getRewardType() {
        return "BADGE";
    }

    @Override
    public UserGamificationProfile apply(Long userId, RewardRule rule, Map<String, Object> context, UserGamificationProfile profile) {
        if (profile.getCurrentLevel() == null) {
            profile.setCurrentLevel(1);
        }
        profile.setTotalBadges(profile.getTotalBadges() + 1);
        return profile;
    }
}
