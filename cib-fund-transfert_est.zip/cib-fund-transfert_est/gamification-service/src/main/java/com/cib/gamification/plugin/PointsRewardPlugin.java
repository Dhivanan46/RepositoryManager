package com.cib.gamification.plugin;

import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserGamificationProfile;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class PointsRewardPlugin implements RewardPlugin {

    @Override
    public String getRewardType() {
        return "POINTS";
    }

    @Override
    public UserGamificationProfile apply(Long userId, RewardRule rule, Map<String, Object> context, UserGamificationProfile profile) {
        BigDecimal points = calculateRewardValue(rule, context);
        profile.setTotalPoints(profile.getTotalPoints().add(points));
        if (profile.getCurrentLevel() == null) {
            profile.setCurrentLevel(1);
        }
        return profile;
    }

    @Override
    public BigDecimal calculateRewardValue(RewardRule rule, Map<String, Object> context) {
        Object amountObj = context.get("amount");
        if (amountObj instanceof Number number) {
            BigDecimal amount = BigDecimal.valueOf(number.doubleValue());
            BigDecimal ruleValue = rule.getRewardValue();
            if (amount.compareTo(BigDecimal.ZERO) > 0) {
                return ruleValue.multiply(amount.divide(BigDecimal.valueOf(100), 0, java.math.RoundingMode.HALF_UP)).max(BigDecimal.ONE);
            }
        }
        return rule.getRewardValue();
    }
}
