package com.cib.gamification.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "application_settings", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"applicationId", "settingKey"})
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationSetting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String applicationId = "bank";

    @Column(nullable = false)
    private String settingKey;

    @Column(nullable = false, precision = 18, scale = 4)
    private BigDecimal settingValue = BigDecimal.ZERO;

    @Column(nullable = false)
    private LocalDateTime updatedAt = LocalDateTime.now();

    @PrePersist
    @PreUpdate
    public void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
