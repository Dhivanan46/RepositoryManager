package com.cib.gamification.repository;

import com.cib.gamification.entity.UserRewardLedger;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRewardLedgerRepository extends JpaRepository<UserRewardLedger, Long> {
    List<UserRewardLedger> findByApplicationIdAndUserIdOrderByAwardedAtDesc(String applicationId, Long userId);
    List<UserRewardLedger> findByUserIdOrderByAwardedAtDesc(Long userId);
}
