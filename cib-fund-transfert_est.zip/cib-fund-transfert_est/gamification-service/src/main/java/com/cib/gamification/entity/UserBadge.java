package com.cib.gamification.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_badges")
@Getter
@Setter
public class UserBadge {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String applicationId = "bank";

    @Column(nullable = false)
    private String badgeName;

    @Column(length = 255)
    private String badgeValue;

    @Column(nullable = false, updatable = false)
    private LocalDateTime earnedAt = LocalDateTime.now();
}
