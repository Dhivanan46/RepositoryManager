package com.cib.gamification.plugin;

import com.cib.gamification.entity.RewardRule;
import com.cib.gamification.entity.UserGamificationProfile;

import java.math.BigDecimal;
import java.util.Map;

public interface RewardPlugin {
    String getRewardType();
    UserGamificationProfile apply(Long userId, RewardRule rule, Map<String, Object> context, UserGamificationProfile profile);
    default BigDecimal calculateRewardValue(RewardRule rule, Map<String, Object> context) {
        return rule.getRewardValue();
    }
}
