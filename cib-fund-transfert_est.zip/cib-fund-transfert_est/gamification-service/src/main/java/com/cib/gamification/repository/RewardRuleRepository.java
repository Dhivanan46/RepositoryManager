package com.cib.gamification.repository;

import com.cib.gamification.entity.RewardRule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RewardRuleRepository extends JpaRepository<RewardRule, Long> {
    List<RewardRule> findByApplicationId(String applicationId);
    List<RewardRule> findByApplicationIdAndStatus(String applicationId, String status);
    List<RewardRule> findByApplicationIdAndEventNameAndStatus(String applicationId, String eventName, String status);
    List<RewardRule> findByStatus(String status);
    List<RewardRule> findByEventNameAndStatus(String eventName, String status);
}
