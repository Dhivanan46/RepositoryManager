package com.cib.gamification.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "gamification_rules")
@Getter
@Setter
public class RewardRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String eventName;

    @Column(nullable = false)
    private String rewardType;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal rewardValue = BigDecimal.ZERO;

    @Column(nullable = false)
    private String status = "ACTIVE";

    @Column(nullable = false)
    private String applicationId = "bank";

    @Column(length = 255)
    private String description;

    @Column(columnDefinition = "TEXT")
    private String configJson;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime validFrom;
    private LocalDateTime validTo;
}
