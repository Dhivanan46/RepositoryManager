package com.cib.gamification.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "user_reward_ledger")
@Getter
@Setter
public class UserRewardLedger {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String applicationId = "bank";

    @Column(nullable = false)
    private String eventName;

    @Column(nullable = false)
    private String rewardType;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal rewardValue = BigDecimal.ZERO;

    @Column(length = 100)
    private String source;

    @Column(nullable = false, updatable = false)
    private LocalDateTime awardedAt = LocalDateTime.now();
}
