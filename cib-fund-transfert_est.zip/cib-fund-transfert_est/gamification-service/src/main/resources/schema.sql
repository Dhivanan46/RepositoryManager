CREATE TABLE IF NOT EXISTS gamification_rules (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(100) NOT NULL,
    reward_type VARCHAR(50) NOT NULL,
    reward_value DECIMAL(12,2) NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    description VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_from DATETIME NULL,
    valid_to DATETIME NULL
);

CREATE TABLE IF NOT EXISTS user_gamification_profile (
    user_id BIGINT PRIMARY KEY,
    total_points DECIMAL(12,2) NOT NULL DEFAULT 0,
    current_level INT NOT NULL DEFAULT 1,
    total_badges INT NOT NULL DEFAULT 0,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_reward_ledger (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    event_name VARCHAR(100) NOT NULL,
    reward_type VARCHAR(50) NOT NULL,
    reward_value DECIMAL(12,2) NOT NULL DEFAULT 0,
    source VARCHAR(100) NULL,
    awarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_badges (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    badge_name VARCHAR(100) NOT NULL,
    badge_value VARCHAR(255) NULL,
    earned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO gamification_rules (event_name, reward_type, reward_value, status, description)
VALUES
('USER_REFERRED', 'POINTS', 100, 'ACTIVE', 'Referral reward'),
('TRANSACTION_COMPLETED', 'POINTS', 25, 'ACTIVE', 'Successful transaction reward'),
('MILESTONE_3_TXNS_7_DAYS', 'BADGE', 1, 'ACTIVE', 'Three transactions in seven days');
