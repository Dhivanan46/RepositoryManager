# CIB Gamification Service

This is a standalone gamification plugin service that uses the same MySQL database as the CIB fund transfer application but runs independently on port 8081.

## Features
- plugin-based reward engine
- configurable rules via database
- points, badges, and coupons support
- user reward history
- user badges tracking
- same DB as the banking app

## Run
```bash
mvn spring-boot:run
```

## Base URL
```text
http://localhost:8081
```

## Example API
```bash
curl http://localhost:8081/api/gamification/rules
curl http://localhost:8081/api/gamification/profile/1
curl -X POST http://localhost:8081/api/gamification/event \
  -H "Content-Type: application/json" \
  -d '{"eventName":"USER_REFERRED","userId":1,"context":{"referredByUserId":2}}'
```
