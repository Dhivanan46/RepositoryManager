# ⚡ Gamification System - Quick Reference

## 🚀 Start Everything (3 steps)

```bash
# Terminal 1: Start MySQL
mysql -u root -p
# Use cib_fund_transfer database

# Terminal 2: Banking App
cd cib-fund-transfer && mvn spring-boot:run
# Runs on http://localhost:8080

# Terminal 3: Gamification Service  
cd gamification-service && mvn spring-boot:run
# Runs on http://localhost:8081
# Dashboard: http://localhost:8081/dashboard.html
```

---

## 📊 Demo in 2 Minutes

### Create Referral Reward
```bash
# User 1 (Referrer - Alice)
curl -X POST http://localhost:8080/api/makers \
  -H "Content-Type: application/json" \
  -d '{"name": "Alice"}'

# User 2 (Referred - Bob)
curl -X POST http://localhost:8080/api/makers \
  -H "Content-Type: application/json" \
  -d '{"name": "Bob", "referralId": "1"}'

# Check rewards
curl http://localhost:8081/api/gamification/profile/2
# ✨ Bob has 100 points!
```

### View on Dashboard
```
Open: http://localhost:8081/dashboard.html
→ Profile tab
→ User ID: 2
→ See 100 Total Points!
```

---

## 🧪 Quick Test Events

### Via Dashboard
1. Open http://localhost:8081/dashboard.html
2. Go to **"🧪 Test Events"** tab
3. Click any test button:
   - Transaction Completed
   - User Referred
   - Custom Event

### Via API
```bash
# Trigger any event
curl -X POST http://localhost:8081/api/gamification/event \
  -H "Content-Type: application/json" \
  -d '{
    "eventName": "TRANSACTION_COMPLETED",
    "userId": 1,
    "context": {"amount": 5000}
  }'
```

---

## 📋 Pre-Configured Rules

| Rule | Event | Reward | Points |
|------|-------|--------|--------|
| Referral | USER_REFERRED | POINTS | 100 |
| Transaction | TRANSACTION_COMPLETED | POINTS | 25 |
| Milestone | MILESTONE_3_TXNS_7_DAYS | BADGE | 1 |

---

## 🌐 Key APIs

### User Profile
```
GET /api/gamification/profile/{userId}
→ totalPoints, currentLevel, totalBadges
```

### Reward History  
```
GET /api/gamification/history/{userId}
→ All rewards earned with timestamps
```

### Trigger Event
```
POST /api/gamification/event
→ { eventName, userId, context }
```

### View Rules
```
GET /api/gamification/rules
→ All active rules and their values
```

---

## 🔌 Adding a New Plugin

```java
@Component
public class MyPlugin implements RewardPlugin {
    @Override
    public String getRewardType() { return "MY_TYPE"; }
    
    @Override
    public UserGamificationProfile apply(Long userId, RewardRule rule,
        Map<String, Object> context, UserGamificationProfile profile) {
        // Your logic here
        return profile;
    }
}
```
Auto-discovers via Spring! No config needed.

---

## 🎯 Add New Rule

```sql
INSERT INTO gamification_rules 
(event_name, reward_type, reward_value, status, description)
VALUES 
('NEW_EVENT', 'POINTS', 50, 'ACTIVE', 'My new rule');
```

Events auto-trigger without code changes!

---

## 📁 File Map

```
cib-fund-transfer/
├── GamificationEventPublisher.java    ← Publishing events to gamification service
├── IntegrationConfig.java             ← REST client config
├── MakerService.java                  ← Emits USER_REFERRED event
└── ApprovalService.java               ← Emits TRANSACTION_COMPLETED event

gamification-service/
├── GamificationService.java           ← Core engine
├── GamificationController.java        ← REST endpoints
├── plugin/
│   ├── RewardPlugin.java              ← Interface for plugins
│   ├── PointsRewardPlugin.java
│   └── BadgeRewardPlugin.java
└── static/dashboard.html              ← Web UI
```

---

## 🐛 Quick Fixes

| Problem | Fix |
|---------|-----|
| "Service not found" | Check services running on 8080 & 8081 |
| "No rewards awarded" | Check rules are ACTIVE in DB |
| "CORS error" | Verify CorsConfig.java exists |
| "DB connection error" | Ensure MySQL running, check credentials |

---

## 📊 Check Status

```bash
# Banking app running?
curl http://localhost:8080/api/makers

# Gamification service running?
curl http://localhost:8081/api/gamification/rules

# Dashboard working?
Open http://localhost:8081/dashboard.html
```

---

## 🎯 Next Steps

1. ✅ Start both services
2. ✅ Access dashboard
3. ✅ Run demo scenarios
4. ✅ Check database tables created
5. ✅ Add new plugins/rules
6. ✅ Deploy to production!

---

## 📚 Full Docs

- **README.md** - Complete overview
- **GAMIFICATION_SETUP_GUIDE.md** - Detailed setup & testing
- **API_DOCUMENTATION.md** - Banking app APIs

---

**Happy Gamifying! 🎮✨**
